// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

// Custom Includes
#include "ForceComp.h"

// Standard Includes

#define LOCTEXT_NAMESPACE "FForceCompModule"

DEFINE_LOG_CATEGORY(LogForces)

void FForceCompModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FForceCompModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module. For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FForceCompModule, ForceComp)