// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

// Custom Includes
#include "ForceComponent.h"
#include <GameFramework/Actor.h>

// Standard Includes

// Sets default values for this component's properties
UForceComponent::UForceComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.
	// You can turn these features off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;
}

void UForceComponent::SetLocationAndRotation(FVector InNewLocation, FRotator InNewRotation, double InDeltaTime, double InTotalTime, uint64 InLoopCtr)
{
	DeviceLocation = InNewLocation;
	DeviceRotation = InNewRotation;

	HapticDeltaTime = InDeltaTime;
	TotalTime = InTotalTime;
	ThreadLoopCounter = InLoopCtr;
}