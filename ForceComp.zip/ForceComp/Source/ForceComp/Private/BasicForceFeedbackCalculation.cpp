// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "BasicForceFeedbackCalculation.h"

#include "CoreMinimal.h" // was added for writing stuff out of an FString

#include "ForceComponent.h"
#include "ColletteStaticMeshComponent.h"

#define USE_SSE 1
THIRD_PARTY_INCLUDES_START
// Undefine UE4 'check' macro
#pragma push_macro("check")
#undef check
#include "ColCollision.h"
#include "ColSphereTree.h"
#pragma pop_macro("check")
THIRD_PARTY_INCLUDES_END

namespace vmath = Vectormath::Aos;

UBasicForceFeedbackCalculation::UBasicForceFeedbackCalculation()
{
}

std::pair<Force, Force> UBasicForceFeedbackCalculation::ComputeForceFeedbackPair(
	const UForceComponent& component1,
	const UForceComponent& component2,
	const std::vector<col::SphereNodeIntersectionData>& sphereNodeIsecData,
	std::pair<FString, double>* OverLapString,
	bool flipIntersectionPairs)
{
	UColletteStaticMeshComponent* collDetComponent1 = Cast<UColletteStaticMeshComponent>(component1.GetOwner()->GetComponentByClass(UColletteStaticMeshComponent::StaticClass()));
	UColletteStaticMeshComponent* collDetComponent2 = Cast<UColletteStaticMeshComponent>(component2.GetOwner()->GetComponentByClass(UColletteStaticMeshComponent::StaticClass()));

	if (!IsValid(collDetComponent1) || !IsValid(collDetComponent2))
	{
		throw col::XCollision("At least one of the objects didn't have a UColletteStaticMeshComponent");
	}

	const UnitMatrix obj1ToWorld = collDetComponent1->GetCollDetMatrix();
	const UnitMatrix obj2ToWorld = collDetComponent2->GetCollDetMatrix();

	Force f1;
	Force f2;

	return std::pair<Force, Force>{f1, f2}; // UBasicForceFeedbackCalculation::ComputeForceFeedbackPair(component1, obj1ToWorld, component2, obj2ToWorld, sphereNodeIsecData, OverLapString, flipIntersectionPairs);
}

std::pair<Force, Force> UBasicForceFeedbackCalculation::ComputeForceFeedbackPair(
	const UForceComponent& component1,
	const UnitMatrix obj1ToWorld,
	const FVector compLocation1,
	const UForceComponent& component2,
	const UnitMatrix obj2ToWorld,
	const FVector compLocation2,
	const std::vector<col::SphereNodeIntersectionData>& sphereNodeIsecData,
	std::pair<FString, double>* OverLapString,
	bool flipIntersectionPairs)
{
	auto result = std::pair<Force, Force>{};

	if (sphereNodeIsecData.empty())
	{
		UE_LOG(LogForces, Log, TEXT("Intersection Data is empty"));
		return result;
	}

	//UE_LOG(LogForces, Log, TEXT("Intersection Data is  NOT empty"));

	double HapticDeltaTime = component1.HapticDeltaTime;

	const UnitQuaternion obj1Rotation = UnitQuaternion{ obj1ToWorld.getUpper3x3() };
	const UnitQuaternion obj2Rotation = UnitQuaternion{ obj2ToWorld.getUpper3x3() };

	const UnitVec obj1Translation = obj1ToWorld.getTranslation();
	const UnitVec obj2Translation = obj2ToWorld.getTranslation();

	// Used so values don't have to be recomputed across below loops.
	std::vector<CachedSpherePairData> cachedData{};

	// Pre-compute and cache sphere pair data for other loops.

	UnitValue totalOverlapVolume = 0.0;
	UnitValue totalImpulseOverlapVolume = 0.0;

	for (const auto& data : sphereNodeIsecData)
	{
		if (data.m_nodeObject1 == nullptr || data.m_nodeObject2 == nullptr)
		{
			UE_LOG(LogForces, Error, TEXT("data had node object that was null"));
			continue;
		}

		if (data.m_nodeObject1->m_radius <= 0.0000001 || data.m_nodeObject2->m_radius <= 0.0000001)
		{
			continue;
		}

		CachedSpherePairData cachedPair{};

		const col::SphereNode& node1 = (!flipIntersectionPairs) ? *data.m_nodeObject1 : *data.m_nodeObject2;
		const col::SphereNode& node2 = (!flipIntersectionPairs) ? *data.m_nodeObject2 : *data.m_nodeObject1;

		UnitPoint node1CenterInWorld = UnitPoint(vmath::rotate(obj1Rotation, UnitVec(node1.m_center)) + obj1Translation);
		UnitPoint node2CenterInWorld = UnitPoint(vmath::rotate(obj2Rotation, UnitVec(node2.m_center)) + obj2Translation);
		const UnitValue centerDist = vmath::dist(node1CenterInWorld, node2CenterInWorld);

		//cachedPair.overlapVolume = getOverlapVolume(node1, node2, centerDist);
		cachedPair.overlapVolume = data.m_overlapVolume;
		if (cachedPair.overlapVolume < 0.0)
		{
			continue;
		}

		totalOverlapVolume += cachedPair.overlapVolume;

		cachedPair.intersection = computeCollisionNormal(node1,
			node1CenterInWorld,
			node2,
			node2CenterInWorld,
			obj1Rotation,
			obj2Rotation);

		// TODO: missing calculation for friction.
		cachedPair.staticFrictionDistCorrection = { 0.0, 0.0, 0.0 };

		const FVector position = compLocation1;
		const FVector position2 = compLocation2;
		cachedPair.interval1 = -(cachedPair.intersection.center - UnitPoint{ static_cast<REAL>(position.X),  static_cast<REAL>(position.Y),  static_cast<REAL>(position.Z) });    // <<--- should be be flipped??
		cachedPair.interval2 = -(cachedPair.intersection.center - UnitPoint{ static_cast<REAL>(position2.X), static_cast<REAL>(position2.Y), static_cast<REAL>(position2.Z) });

		// TODO: The members used here are not filled yet.
		const auto currentTimePerMass = std::make_pair(HapticDeltaTime / component1.Mass, HapticDeltaTime / component2.Mass);
		const auto currentSpeedFromForce = std::make_pair(ToUnitVec(component1.CurrentForce) * currentTimePerMass.first,
			ToUnitVec(component2.CurrentForce) * currentTimePerMass.second);
		const auto currentSpeedFromTorque = std::make_pair(ToUnitMatrix(component1.InverseWorldInertiaTensor) * ToUnitVec(component1.CurrentTorque),
			ToUnitMatrix(component2.InverseWorldInertiaTensor) * ToUnitVec(component2.CurrentTorque));

		const UnitVec tangentialVelocity =
			vmath::cross(ToUnitVec(component1.AngularVelocity), cachedPair.interval1) + ToUnitVec(component1.PrevTickVelocityVector)
			- (vmath::cross(ToUnitVec(component2.AngularVelocity), cachedPair.interval2) + ToUnitVec(component2.PrevTickVelocityVector))
			- cachedPair.staticFrictionDistCorrection
			+ currentSpeedFromForce.first
			- currentSpeedFromForce.second
			+ (vmath::cross(currentSpeedFromTorque.first.getXYZ(), cachedPair.interval1))
			- (vmath::cross(currentSpeedFromTorque.second.getXYZ(), cachedPair.interval2));

		cachedPair.normalVelocityMagnitude = vmath::dot(tangentialVelocity, cachedPair.intersection.normal);
		if (cachedPair.normalVelocityMagnitude < 0.0)
		{
			totalImpulseOverlapVolume += cachedPair.overlapVolume;
		}

		// TODO: missing calculation for limits (requires some not yet implemented members).
		const UnitVec translationLimit = cachedPair.intersection.normal * currentTimePerMass.first + cachedPair.intersection.normal * currentTimePerMass.second;
		const UnitVec rotationLimit = vmath::dot(vmath::cross((ToUnitMatrix(component1.InverseWorldInertiaTensor) * vmath::cross(cachedPair.interval1, cachedPair.intersection.normal) * HapticDeltaTime).getXYZ(), cachedPair.interval1), cachedPair.intersection.normal) * cachedPair.intersection.normal
			- vmath::dot(vmath::cross((ToUnitMatrix(component2.InverseWorldInertiaTensor) * vmath::cross(cachedPair.interval2, -cachedPair.intersection.normal) * HapticDeltaTime).getXYZ(), cachedPair.interval2), -cachedPair.intersection.normal) * -cachedPair.intersection.normal;
		cachedPair.normalForceLimit = translationLimit + rotationLimit;

		cachedData.push_back(cachedPair);
	}
	OverLapString->first = FString::SanitizeFloat(totalOverlapVolume);

	FString volS = OverLapString->first;

	// Calculate simple restitution and torque forces.

	UnitValue totalRestitution = 0.0; // TODO: Used later for friction.
	for (auto& cachedPair : cachedData)
	{
		const UnitValue normalForceLimitSquareLength =
			vmath::lengthSqr(cachedPair.normalForceLimit);

		// Avoid division by zero in computeSimpleRestitution().
		if (normalForceLimitSquareLength < 0.0)
		{
			continue;
		}

		cachedPair.restitution = computeSimpleRestitution(
			cachedPair.overlapVolume,
			totalOverlapVolume,
			cachedPair.normalVelocityMagnitude,
			component1.Stiffness,
			component1.RestitutionDamper); // TODO: What about component2?

		cachedPair.restitution = std::max(cachedPair.restitution, UnitValue{ 0.0 });
		totalRestitution += cachedPair.restitution;

		result.first.restitution += cachedPair.intersection.normal * cachedPair.restitution;
		result.second.restitution += -cachedPair.intersection.normal * cachedPair.restitution;

		result.first.torque += vmath::cross(cachedPair.interval1, result.first.restitution);
		result.second.torque += vmath::cross(cachedPair.interval2, result.second.restitution);
	}

	// TODO: missing calculation for friction forces.

	return result;
}

/**
* Return volume of the intersection ellipse.
*/
UnitValue UBasicForceFeedbackCalculation::getOverlapVolume(const col::SphereNode& node1, const col::SphereNode& node2, const UnitValue centerDist)
{
	UnitValue r1 = node1.m_radius;
	UnitValue r2 = node2.m_radius;

	if (centerDist > r1 + r2)
	{
		// No overlap
		return 0.0;
	}

	bool firstNodeBigger = false;
	if (r1 > r2)
	{
		firstNodeBigger = true;
		r1 = node2.m_radius;
		r2 = node1.m_radius;
	}

	if (centerDist <= std::abs(r2 - r1))
	{
		return node1.m_volumeRatio * node2.m_volumeRatio
			* (firstNodeBigger ? node1.m_volumeInner : node2.m_volumeInner);
	}

	const UnitValue x1 = (centerDist * centerDist + r1 * r1 - r2 * r2) / (2.0 * centerDist);
	const UnitValue h1 = r1 - x1;
	const UnitValue h2 = r2 + x1 - centerDist;

	// Use expected overlap volume.
	return node1.m_volumeRatio * node2.m_volumeRatio * M_PI / 3.0
		* (h1 * h1 * (3 * r1 - h1) + h2 * h2 * (3 * r2 - h2));
}

/**
* Calculates simple restitution (penalty) force.
* Masses of objects are not regarded.
* See Hestermann 2016, p. 28, eq. 4.8
*/
UnitValue UBasicForceFeedbackCalculation::computeSimpleRestitution(UnitValue localOverlapVolume,
	UnitValue totalOverlapVolume,
	UnitValue velocityMagnitude,
	UnitValue stiffness,
	UnitValue damper)
{
	return (localOverlapVolume * (stiffness - (velocityMagnitude * damper) / totalOverlapVolume));
}

SphereIntersection UBasicForceFeedbackCalculation::computeCollisionNormal(const col::SphereNode& first,
	const UnitPoint& firstCenterInWorld,
	const col::SphereNode& second,
	const UnitPoint& secondCenterInWorld,
	const UnitQuaternion& rotationFirst,
	const UnitQuaternion& rotationSecond)
{
	//TODO (Sascha) Check for all possible cases of the resulting normal becoming zero or undefined

	UnitVec centerDiff = firstCenterInWorld - secondCenterInWorld;
	// (Sascha) Required for torque
	UnitPoint centerOfCollision = secondCenterInWorld + (second.m_radius / (first.m_radius + second.m_radius)) * centerDiff;

	SphereIntersection result;
	result.center = centerOfCollision;

	// TODO: Previously only for testing, currently in use since the normal cone cases have a bug (see below)
	// Use only standard (naiive) method for calculating collision normal (i.e. use distance between sphere centers)
	result.normal = (vmath::length(centerDiff) != 0)
		? centerDiff
		: UnitVec{ col::pseudo_randomf(), col::pseudo_randomf(), col::pseudo_randomf() };
	result.normal = vmath::normalize(result.normal);
	return result;

	//if (length(centerDiff) != 0)
	//{
	//	centerDiff = vmath::normalize(centerDiff); // This is B-i - A_i / || B_i - A_i ||.
	//}

	//const REAL MAGIC_180_DEGREE = M_PI - 0.00000001;
	//const REAL MAGIC_NORMAL_ANGLE_OFFSET = 0.000001;

	// Handle all the different normal cone cases.
	//UnitVec collisionNormal{ 0 };

	//if (first.m_normalAngle > MAGIC_180_DEGREE && second.m_normalAngle > MAGIC_180_DEGREE) { // TODO: Somewhere here is a bug, wrong force direction
	//collisionNormal = centerDiff;
	//} else if (second.m_normalAngle > MAGIC_180_DEGREE) { // K_B_i > 180					// TODO: Somewhere here is a bug, wrong force direction
	//    collisionNormal = computeNormalWhenOverlargeCone(first.m_normal,
	//                                                     first.m_normalAngle,
	//                                                     rotationFirst,
	//                                                     centerDiff);
	//} else if (first.m_normalAngle > MAGIC_180_DEGREE) { // K_A_i > 180
	//    collisionNormal = computeNormalWhenOverlargeCone(second.m_normal,
	//                                                     -second.m_normalAngle,
	//                                                     rotationSecond,
	//                                                     centerDiff);
	//} else {
	//    UnitVec normalConeFirst = vmath::rotate(rotationFirst, first.m_normal);
	//    UnitVec normalConeSecond = vmath::rotate(rotationFirst, -second.m_normal);

	//    collisionNormal = normalConeFirst + normalConeSecond;
	//    if (first.m_normalAngle < MAGIC_NORMAL_ANGLE_OFFSET && second.m_normalAngle < MAGIC_NORMAL_ANGLE_OFFSET) { // K_A_i = 0 && K_B_i = 0
	//        if (vmath::length(collisionNormal) == 0.0) {
	//            collisionNormal = centerDiff;
	//        } // Is else properly handled here by Sascha? See peudocode p.27, l. 27f.
	//    } else {
	//        if (vmath::length(collisionNormal) == 0) {
	//            collisionNormal = centerDiff;
	//        } else {
	//            collisionNormal = vec3Slerp(normalConeFirst,
	//                                        normalConeSecond,
	//                                        first.m_normalAngle / (first.m_normalAngle + second.m_normalAngle));
	//        }
	//    }
	//}

	//result.normal = vmath::normalize(collisionNormal);
	//return result;
}

UnitVec UBasicForceFeedbackCalculation::computeNormalWhenUndefined(const UnitVec& centerDiff)
{
	return (vmath::length(centerDiff) != 0)
		? centerDiff : UnitVec{ col::pseudo_randomf(), col::pseudo_randomf(), col::pseudo_randomf() };
}

UnitVec UBasicForceFeedbackCalculation::computeNormalWhenOverlargeCone(const UnitVec& sphereNodeNormal,
	const UnitValue& sphereNodeNormalAngle,
	const UnitQuaternion& sphereNodeRotation,
	const UnitVec& centerDiff)
{
	UnitVec collisionNormal = vmath::rotate(sphereNodeRotation, sphereNodeNormal); // Normal is set to cone

	if (vmath::length(centerDiff) != 0)
	{
		if (vmath::dot(centerDiff, collisionNormal) < std::cos(sphereNodeNormalAngle))
		{
			collisionNormal = vec3Slerp(collisionNormal, centerDiff, 1.0f, sphereNodeNormalAngle);
		}
		else
		{
			// (Sascha) Try to use center diff as long as it is inside the other cone
			collisionNormal = centerDiff;
		}
	}

	return collisionNormal;
}

UnitVec UBasicForceFeedbackCalculation::vec3Slerp(UnitVec start, UnitVec end, UnitValue percent, UnitValue maxAngle)
{
	// Code taken from: https://keithmaggio.wordpress.com/2011/02/15/math-magician-lerp-slerp-and-nlerp/
	// Dot product - the cosine of the angle between 2 vectors.
	// Clamp it to be in the range of Acos()
	// This may be unnecessary, but floating point
	// precision can be a fickle mistress.
	const UnitValue clampedDot =
		std::max(static_cast<UnitValue>(-1.0),
			std::min(vmath::dot(start, end), static_cast<UnitValue>(1.0)));

	// Acos(dot) returns the angle between start and end,
	// And multiplying that by percent returns the angle between
	// start and the final result.
	const UnitValue theta = std::min(acos(clampedDot) * percent, maxAngle);
	UnitVec relativeVec = (end - start) * clampedDot;
	if (length(relativeVec) != 0)
	{
		relativeVec = normalize(relativeVec); // Orthonormal basis
	}

	// The final result.
	const UnitVec resVec = (start * cos(theta)) + (relativeVec * sin(theta));
	if (isnan(resVec[0]) || isnan(resVec[1]) || isnan(resVec[2]))
	{
		printf("Slerp res: %10f %10f %10f\n", resVec[0], resVec[1], resVec[2]);
		printf("Slerp dot: %10f\n", clampedDot);
		printf("Slerp theta: %10f\n", theta);
		printf("Slerp relative: %10f %10f %10f\n", relativeVec[0], relativeVec[1], relativeVec[2]);
		printf("Slerp percentage: %10f\n", percent);
		printf("Slerp start: %10f %10f %10f\n", start[0], start[1], start[2]);
		printf("Slerp end: %10f %10f %10f\n", end[0], end[1], end[2]);
	}
	assert(!isnan(resVec[0]) && !isnan(resVec[1]) && !isnan(resVec[2]));
	return resVec;
}

UnitVec UBasicForceFeedbackCalculation::ToUnitVec(const FVector& v)
{
	return UnitVec{ static_cast<REAL>(v[0]), static_cast<REAL>(v[1]), static_cast<REAL>(v[2]) };
}

FVector UBasicForceFeedbackCalculation::ToFVector(const UnitVec& v)
{
	return FVector{ static_cast<REAL>(v[0]), static_cast<REAL>(v[1]), static_cast<REAL>(v[2]) };
}

UnitVec4 UBasicForceFeedbackCalculation::ToUnitVec4(const FVector4& v)
{
	return UnitVec4(static_cast<REAL>(v[0]), static_cast<REAL>(v[1]), static_cast<REAL>(v[2]), static_cast<REAL>(v[3]));
}

UnitVec4 UBasicForceFeedbackCalculation::ToUnitVec4(const FMatrix& m, int32 col)
{
	return ToUnitVec4(FVector4{ m.M[col][0], m.M[col][1], m.M[col][2], m.M[col][3] });
}

UnitMatrix UBasicForceFeedbackCalculation::ToUnitMatrix(const FMatrix& m)
{
	UnitVec4 col0 = ToUnitVec4(m, 0);
	UnitVec4 col1 = ToUnitVec4(m, 1);
	UnitVec4 col2 = ToUnitVec4(m, 2);
	UnitVec4 col3 = ToUnitVec4(m, 3);
	return UnitMatrix(col0, col1, col2, col3);
}

UnitMatrix UBasicForceFeedbackCalculation::ToUnitMatrix(const FTransform& InTransform)
{
	FMatrix tempMatrix = InTransform.ToMatrixNoScale();
	return ToUnitMatrix(tempMatrix);
}