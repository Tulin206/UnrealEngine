// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "ForceComp.h"
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ForceComponent.generated.h"

// Standard Includes

UENUM()
enum class EForceType
{
	STATIC,
	MOVING
};

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent),
	HideCategories = ("Rendering", "Tags", "Activation", "Cooking", "Collision", "Input"),
	autoExpandCategories = "Force")
	class FORCECOMP_API UForceComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UForceComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		int id = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Force")
		float Mass = 0.2f;

	/*
	 * An emprically determined value that scales the force.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Force|Restitution")
		float Stiffness = 10.0f;

	/*
	 * A magic value that has to be tweaked per object.
	 * Corresponds to restitution caused by the velocity in normal cone direction.
	 * Value should be between 0 and 1.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Force|Restitution")
		float RestitutionDamper = 0.0f;

	/*
		Used for torques which are currently not fully implemented
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Force|Torque")
		FMatrix InverseWorldInertiaTensor;

	/*
		Decides about the behaviour in ForceComputations
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Force")
		EForceType ForceType = EForceType::STATIC;

	/*
		Factor for the displacement vector during the spring force calculation for virtual coupling
		Named after the usual variable name for it in literature
	*/
	UPROPERTY(EditAnywhere, meta = (ClampMin = 0, UIMin = 0), Category = "Force|Virtual Coupling")
		float k = 10.0f;

	/*
		Factor for the velocity vector during the spring force calculation for virtual coupling
		Named after the usual variable name for it in literature
	*/
	UPROPERTY(EditAnywhere, Category = "Force|Virtual Coupling")
		float b = 10.0f;

	/*
		If the length of the displacement vector is smaller than this, then the spring force is set to zero
	*/
	UPROPERTY(EditAnywhere, Category = "Force|Virtual Coupling")
		float Sensitivity = 0.01f;

	////////////////////////////////////////////////////////////////////

	// Temporarily store velocity from parent actor.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		double HapticDeltaTime;

	// Temporarily store the loop number the thread was at from parent actor.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		uint64 ThreadLoopCounter;

	// Temporarily store velocity from parent actor.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		FVector PrevTickVelocityVector;

	// TODO this value is used, but not actually updated (aka its always the zero vector) because virtual coupling with torque isn't fully implemented
	// Temporarily store angular velocity from parent actor.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		FVector AngularVelocity;

	// Temporarily store current force.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		FVector CurrentForce;

	// Temporarily store current torque.
	UPROPERTY(VisibleAnywhere, Category = "Force|Info")
		FVector CurrentTorque;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Force|Info")
		FVector DeviceLocation;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Force|Info")
		FRotator DeviceRotation;

	double TotalTime;

	void SetLocationAndRotation(FVector NewLocation, FRotator NewRotation, double InDeltaTime, double InTotalTime, uint64 InLoopCtr);
};
