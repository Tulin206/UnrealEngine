// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#define _USE_MATH_DEFINES // For M_PI
#include <cmath>          // For M_PI

#include "ForceComp.h"
#include "VectorDefines.h"
#include "ForceComponent.h"
#include "ColletteStaticMeshComponent.h"

#include <utility>
#include <vector>

#define USE_NEW_COLLDET

#include "Kismet/BlueprintFunctionLibrary.h"
#include "BasicForceFeedbackCalculation.generated.h"

namespace col
{
	class SphereNode;
	struct SphereNodeIntersectionData;
}

struct Force
{
	UnitVec restitution;
	UnitVec torque;
};

struct SphereIntersection
{
	UnitVec normal;
	UnitPoint center;
};

struct CachedSpherePairData
{
	UnitValue overlapVolume;
	SphereIntersection intersection;
	UnitVec interval1;
	UnitVec interval2;
	UnitVec normalForceLimit;
	UnitVec staticFrictionDistCorrection;
	UnitValue normalVelocityMagnitude;
	UnitValue restitution;
};

UCLASS()
class FORCECOMP_API UBasicForceFeedbackCalculation : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
public:

	UBasicForceFeedbackCalculation();

public:

	static std::pair<Force, Force> ComputeForceFeedbackPair(
		const UForceComponent& component1,
		const UForceComponent& component2,
		const std::vector<col::SphereNodeIntersectionData>& sphereNodeIsecData,
		std::pair<FString, double>* OverLapString,
		bool flipIntersectionPairs);

	static std::pair<Force, Force> ComputeForceFeedbackPair(
		const UForceComponent& component1,
		const UnitMatrix obj1ToWorld,
		const FVector compLocation1,
		const UForceComponent& component2,
		const UnitMatrix obj2ToWorld,
		const FVector compLocation2,
		const std::vector<col::SphereNodeIntersectionData>& sphereNodeIsecData,
		std::pair<FString, double>* OverLapString,
		bool flipIntersectionPairs);

private:

	static UnitValue getOverlapVolume(const col::SphereNode& node1, const col::SphereNode& node2, const UnitValue centerDist);

	static UnitValue computeSimpleRestitution(UnitValue localOverlapVolume,
		UnitValue totalOverlapVolume,
		UnitValue velocityMagnitude,
		UnitValue stiffness,
		UnitValue damper);

	static SphereIntersection computeCollisionNormal(const col::SphereNode& first,
		const UnitPoint& firstCenterInWorld,
		const col::SphereNode& second,
		const UnitPoint& secondCenterInWorld,
		const UnitQuaternion& rotationFirst,
		const UnitQuaternion& rotationSecond);

	static UnitVec computeNormalWhenUndefined(const UnitVec& centerDiff);

	static UnitVec computeNormalWhenOverlargeCone(const UnitVec& sphereNodeNormal,
		const UnitValue& sphereNodeNormalAngle,
		const UnitQuaternion& sphereNodeRotation,
		const UnitVec& centerDiff);

	static UnitVec vec3Slerp(UnitVec start, UnitVec end, UnitValue percent, UnitValue maxAngle = M_PI);

	static UnitVec ToUnitVec(const FVector& v);
	static FVector ToFVector(const UnitVec& v);

	static UnitVec4 ToUnitVec4(const FVector4& v);
	static UnitVec4 ToUnitVec4(const FMatrix& m, int32 col);

	static UnitMatrix ToUnitMatrix(const FMatrix& m);
	static UnitMatrix ToUnitMatrix(const FTransform& InTransform);

	static const FString ToString(const UnitMatrix& InMatrix4)
	{
		return FString::Printf(TEXT(" ### Matrix4 ### \n")) +
			FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(0, 0)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(1, 0)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(2, 0)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(3, 0)) + FString("\n") +
			FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(0, 1)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(1, 1)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(2, 1)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(3, 1)) + FString("\n") +
			FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(0, 2)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(1, 2)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(2, 2)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(3, 2)) + FString("\n") +
			FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(0, 3)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(1, 3)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(2, 3)) + FString::Printf(TEXT(" %+8.8f "), InMatrix4.getElem(3, 3)) + FString("\n") +
			FString::Printf(TEXT("\n"));
	}
};