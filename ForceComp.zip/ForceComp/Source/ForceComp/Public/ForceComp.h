// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

// Custom Includes
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogForces, All, All)

class FForceCompModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};