// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

// Custom Includes
#include "vectormath/scalar/cpp/vectormath_aos.h"

using UnitValue = REAL;
using UnitPoint = Vectormath::Aos::Point3;
using UnitVec = Vectormath::Aos::Vector3;
using UnitVec4 = Vectormath::Aos::Vector4;
using UnitMatrix = Vectormath::Aos::Matrix4;
using UnitQuaternion = Vectormath::Aos::Quat;
