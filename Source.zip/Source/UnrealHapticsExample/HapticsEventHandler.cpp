// Fill out your copyright notice in the Description page of Project Settings.

#include "HapticsEventHandler.h"
#include "DrawDebugHelpers.h"
#include "ForceComponent.h"
#include "ColletteUtils.h"
#include <numeric>

#define USE_SSE 1
THIRD_PARTY_INCLUDES_START
// Undefine UE4 'check' macro
#pragma push_macro("check")
#undef check
#include "ColCollision.h"
#include "ColSphereTree.h"
#pragma pop_macro("check")
THIRD_PARTY_INCLUDES_END

DEFINE_LOG_CATEGORY(LogHapticsEventHandler)

// Sets default values
AHapticsEventHandler::AHapticsEventHandler()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
}

/// <summary>
/// Called when the game starts or when spawned.
/// Sets the delegators and starts the tick of this object.
/// </summary>
void AHapticsEventHandler::BeginPlay()
{
	Super::BeginPlay();

	if (!ColletteManager)
	{
		V_LOG(LogHapticsEventHandler, Error, "No ColletteManager associated.");

		return;
	}

	ColletteManager->OnCollision.addDelegate(std::bind(&AHapticsEventHandler::HandleCollision, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3));

	SetActorTickEnabled(true);

	// seeding the random number generator, probably originally for benchmarking?
	//srand(1234);

	if (!DeviceActor)
	{
		V_LOG(LogHapticsEventHandler, Error, "No DeviceActor associated.");
		return;
	}

	auto ColleteComponent = DeviceActor->FindComponentByClass<UColletteStaticMeshComponent>();

	if (!ColleteComponent)
	{
		V_LOG(LogHapticsEventHandler, Error, TEXT("No ColleteComponent(s) on DeviceActor"));
		return;
	}

	if (!AssociatedHapticsManager)
	{
		V_LOG(LogHapticsEventHandler, Error, "No HapticsManager associated.");
		return;
	}

	if (IHaptico::Get().findDeviceOfType(Device))
	{
		UE_LOG(LogTemp, Warning, TEXT("Found Device of Type: "), Device);
		AssociatedHapticsManager->StartHapticThread();
		IHaptico::Get().SetDeviceType(Device);
	}
	else {
		UE_LOG(LogTemp, Error, TEXT("No Device of Type found: "), Device);
	}

	DeviceForceComponent = DeviceActor->FindComponentByClass<UForceComponent>();
	DeviceActor->GetComponents<UForceComponent>(DeviceContactPoints);
	DeviceActor->GetComponents<UColletteStaticMeshComponent>(CollMeshes);

	


	if (!DeviceForceComponent)
	{
		V_LOG(LogHapticsEventHandler, Error, TEXT("No ForceComponent(s) on DeviceActor"));
		return;
	}

	


	RestitutionForceBuffers.resize(DeviceContactPoints.Num());
	DeviceLocationBuffers.resize(DeviceContactPoints.Num());
	VirtualDeviceLocationBuffers.resize(DeviceContactPoints.Num());
	VirtualPhaseDeviceLocationBuffers.resize(DeviceContactPoints.Num());
	PossibleCollisionTupel.resize(DeviceContactPoints.Num());

	AssociatedHapticsManager->OnCalculateForce.addDelegate(std::bind(&AHapticsEventHandler::HandleForceFeedbackCalculation, this));
	AssociatedHapticsManager->OnAfterCalibratingDevice.BindUObject(this, &AHapticsEventHandler::HandleAfterCalibratingDevice);
	AssociatedHapticsManager->OnAfterGatheringHapticData.addDelegate(std::bind(&AHapticsEventHandler::HandleNewHapticData, this, std::placeholders::_1));

	AssociatedHapticsManager->OnButton1Clicked.BindUFunction(this, "OnButton1Clicked");
	AssociatedHapticsManager->OnButton2Clicked.BindUFunction(this, "OnButton2Clicked");

	//for (int i = 0; i < DeviceContactPoints.Num(); i++)
	//{
	//	PossibleCollisionTupel.push_back(std::make_tuple(nullptr, nullptr, nullptr));
	//	RestitutionForceBuffers.resize(DeviceContactPoints.Num());
	//}
}

void AHapticsEventHandler::OnButton1Clicked()
{
	OnActionButton1Clicked.Broadcast();
}

void AHapticsEventHandler::OnButton2Clicked()
{
	OnActionButton2Clicked.Broadcast();
}

void AHapticsEventHandler::EndPlay(EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

/// <summary>
/// Handles the new haptic data.
/// Currently this means to give the data to the ForceComponent of the device actor
/// </summary>
/// <param name="InDeviceData">The device data.</param>
void AHapticsEventHandler::HandleNewHapticData(const FHapticData& InDeviceData)
{
	/*FVector TranslatedLocation = AssociatedHapticsManager->TranslateHapticLocationAndScaleToFVector(InDeviceData.location, AssociatedHapticsManager->TranslationScale);
	FRotator TranslatedRotation = AssociatedHapticsManager->TranslateToUnrealRotator(InDeviceData.rotation);

	DeviceForceComponent->SetLocationAndRotation(TranslatedLocation, TranslatedRotation, InDeviceData.DeltaTime, InDeviceData.TotalTime, InDeviceData.loopCtr);*/

	for (int i = 0; i < InDeviceData.locations.size(); i++) 
	{
		for (UForceComponent* fc : DeviceContactPoints) 
		{
			if (fc->id == i) {
				FVector location = AssociatedHapticsManager->TranslateHapticLocationAndScaleToFVector(InDeviceData.locations[i], AssociatedHapticsManager->TranslationScale);
/*				TArray<UStaticMeshComponent*> components;
				DeviceActor->GetComponents<UStaticMeshComponent>(components);
				FVector local = components[0]->GetComponentTransform().InverseTransformVector(location);
				switch (i)
				{
				case 1:
					
					
					local.X = local.X + 6;
					local.Y = local.Y - 46;
					local.Z = local.Z - 39;

					location = components[0]->GetComponentTransform().TransformVector(local);

					break;
				case 2:
					local.X = local.X - 4;
					local.Y = local.Y - 79;
					local.Z = local.Z - 25;

					location = components[0]->GetComponentTransform().TransformVector(local);
					break;
				default:
					*///break;
				//}
				
				FRotator rotation = AssociatedHapticsManager->TranslateToUnrealRotator(InDeviceData.rotations[i]);
				fc->SetLocationAndRotation(location, rotation, InDeviceData.DeltaTime, InDeviceData.TotalTime, InDeviceData.loopCtr);
				break;
			}
		}
	}
}

AHapticsEventHandler::~AHapticsEventHandler()
{
}

// Called every frame
void AHapticsEventHandler::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bDrawDebugArrows)
	{
		DrawDebugInfo();
	}
}

/// <summary>
/// Handles the collision.
/// Just thread safe storing of the values of the collision,
/// aka both the collision components and the collision data.
/// </summary>
/// <param name="InFirstCollDetStaticMeshComponent">The first UColletteStaticMeshComponent, which takes part in the collision.</param>
/// <param name="InSecondCollDetStaticMeshComponent">The second UColletteStaticMeshComponent, which takes part in the collision.</param>
/// <param name="collisionData">The CollDet collision data.</param>
void AHapticsEventHandler::HandleCollision(
	UColletteStaticMeshComponent& InFirstCollDetStaticMeshComponent,
	UColletteStaticMeshComponent& InSecondCollDetStaticMeshComponent,
	const col::Data* const collisionData)
{
	intersectionDataLock.lock();

	//UE_LOG(LogTemp, Warning, TEXT("Collision"));
	if (DeviceActor == InFirstCollDetStaticMeshComponent.GetOwner() && InFirstCollDetStaticMeshComponent.ID < PossibleCollisionTupel.size())
	{
		std::get<0>(this->PossibleCollisionTupel[InFirstCollDetStaticMeshComponent.ID]) = &InFirstCollDetStaticMeshComponent;
		std::get<1>(this->PossibleCollisionTupel[InFirstCollDetStaticMeshComponent.ID]) = &InSecondCollDetStaticMeshComponent;
		std::get<2>(this->PossibleCollisionTupel[InFirstCollDetStaticMeshComponent.ID]) = collisionData;
	}
	else if (DeviceActor == InSecondCollDetStaticMeshComponent.GetOwner() && InSecondCollDetStaticMeshComponent.ID < PossibleCollisionTupel.size())
	{
		std::get<0>(this->PossibleCollisionTupel[InSecondCollDetStaticMeshComponent.ID]) = &InSecondCollDetStaticMeshComponent;
		std::get<1>(this->PossibleCollisionTupel[InSecondCollDetStaticMeshComponent.ID]) = &InFirstCollDetStaticMeshComponent;
		std::get<2>(this->PossibleCollisionTupel[InSecondCollDetStaticMeshComponent.ID]) = collisionData;
	}

	//UE_LOG(LogTemp, Warning, TEXT("IN First: %d"), InFirstCollDetStaticMeshComponent.GetCollDetObject()->GetCollDetID());
	//UE_LOG(LogTemp, Warning, TEXT("IN Second: %d"), InSecondCollDetStaticMeshComponent.GetCollDetObject()->GetCollDetID());

	//this->FirstCollDetStaticMeshComponent = &InFirstCollDetStaticMeshComponent;
	//this->SecondCollDetStaticMeshComponent = &InSecondCollDetStaticMeshComponent;
	//this->lastCollisionData = collisionData;
	
	//UE_LOG(LogTemp, Warning, TEXT("OUT First: %d"), std::get<0>(PossibleCollisionTupel[0])->ID);
	//UE_LOG(LogTemp, Warning, TEXT("OUT Second: %d"), this->SecondCollDetStaticMeshComponent->GetCollDetObject()->GetCollDetID());


	intersectionDataLock.unlock();
}

/// <summary>
/// Calculates the forces and then calls StoreForce.
/// </summary>
void AHapticsEventHandler::HandleForceFeedbackCalculation()
{
	for (int i = 0; i < 3; i++)
	{
		if (!std::get<0>(PossibleCollisionTupel[i]) || !std::get<1>(PossibleCollisionTupel[i]))
		{
			continue;
		}
		TArray<UForceComponent*> FirstForceComponents;
		TArray<UForceComponent*> SecondForceComponents;
		std::get<0>(PossibleCollisionTupel[i])->GetOwner()->GetComponents<UForceComponent>(FirstForceComponents);
		std::get<1>(PossibleCollisionTupel[i])->GetOwner()->GetComponents<UForceComponent>(SecondForceComponents);

		if (FirstForceComponents.IsEmpty() || SecondForceComponents.IsEmpty()) {
			FString missingComponent;

			if (FirstForceComponents.IsEmpty()) {
				missingComponent = FirstCollDetStaticMeshComponent->GetName();
			}
			else {
				missingComponent = SecondCollDetStaticMeshComponent->GetName();
			}
			continue;
		}

		UForceComponent* forceComponent1 = nullptr;
		for (UForceComponent* comp : FirstForceComponents)
		{
			if (comp->id == i)
			{
				forceComponent1 = comp;
				break;
			}
		}

		if (!forceComponent1)
		{
			UE_LOG(LogHapticsEventHandler, Error, TEXT("No ForceComp with fitting ID"));
			return;

		}
		auto forceComponent2 = SecondForceComponents[0];

		// Comment Archive
		{

			//if (!FirstCollDetStaticMeshComponent || !SecondCollDetStaticMeshComponent)
			//{
			//	if (!FirstCollDetStaticMeshComponent && !SecondCollDetStaticMeshComponent)
			//	{
			//		// display no error since this is probably the initial startup

			//		//UE_LOG(LogHapticsEventHandler, Error, TEXT("First and second actor missing"));
			//	}
			//	else if (!FirstCollDetStaticMeshComponent)
			//	{
			//		UE_LOG(LogHapticsEventHandler, Error, TEXT("First actor missing"));
			//	}
			//	else
			//	{
			//		UE_LOG(LogHapticsEventHandler, Error, TEXT("Second actor missing"));
			//	}

			//	return;
			//}
			//intersectionDataLock.lock();

			 // collisions between two non device actors get ignored here
			//if (FirstCollDetStaticMeshComponent->GetOwner() != DeviceActor && SecondCollDetStaticMeshComponent->GetOwner() != DeviceActor)
			//{
			//	return;
			//}
			//bool deviceWasSecond = DeviceActor != FirstCollDetStaticMeshComponent->GetOwner();
			//if (deviceWasSecond)
			//{
			//	auto tempCollDetComp = FirstCollDetStaticMeshComponent;
			//	FirstCollDetStaticMeshComponent = SecondCollDetStaticMeshComponent;
			//	SecondCollDetStaticMeshComponent = tempCollDetComp;
			//}

			//TArray<UForceComponent*> FirstForceComponents;
			//TArray<UForceComponent*> SecondForceComponents;
			//FirstCollDetStaticMeshComponent->GetOwner()->GetComponents<UForceComponent>(FirstForceComponents);
			//SecondCollDetStaticMeshComponent->GetOwner()->GetComponents<UForceComponent>(SecondForceComponents);

			//if (FirstForceComponents.IsEmpty() || SecondForceComponents.IsEmpty()) {
			//	FString missingComponent;

			//	if (FirstForceComponents.IsEmpty()) {
			//		missingComponent = FirstCollDetStaticMeshComponent->GetName();
			//	}
			//	else {
			//		missingComponent = SecondCollDetStaticMeshComponent->GetName();
			//	}
			//	return;
			//}
			//UForceComponent* forceComponent1 = nullptr;


			//forceComponent1 = FirstForceComponents[0];
			//for (UForceComponent* fc : FirstForceComponents)
			//{
			//	if (FirstCollDetStaticMeshComponent->ID == fc->id) {
			//		forceComponent1 = fc;
			//	}
			//}

			//if (forceComponent1 == nullptr)
			//{
			//	UE_LOG(LogHapticsEventHandler, Error, TEXT("No ForceComp with fitting ID"));
			//	return;
			//}

			//auto forceComponent2 = SecondForceComponents[0];


			//auto forceComponent1 = FirstCollDetStaticMeshComponent->GetOwner()->FindComponentByClass<UForceComponent>();
			//auto forceComponent2 = SecondCollDetStaticMeshComponent->GetOwner()->FindComponentByClass<UForceComponent>();
			//if (!forceComponent1 || !forceComponent2)
			//{
			//	// maybe implement proper error handling for missing force component.

			//	FString missingComponent;

			//	if (!forceComponent1)
			//	{
			//		missingComponent = FirstCollDetStaticMeshComponent->GetName();

			//		if (!forceComponent2)
			//		{
			//			missingComponent += " and " + SecondCollDetStaticMeshComponent->GetName();
			//		}
			//	}
			//	else
			//	{
			//		missingComponent = SecondCollDetStaticMeshComponent->GetName();
			//	}

			//	UE_LOG(LogHapticsEventHandler, Error, TEXT("ForceComponent(s) missing on %s"), *missingComponent);

			//	return;
			//}

			//// collisions between two non device actors get ignored here
			//if (DeviceActor != forceComponent1->GetOwner() && DeviceActor != forceComponent2->GetOwner())
			//{
			//	return;
			//}

			//bool deviceWasSecond = DeviceActor != forceComponent1->GetOwner();

			//// swap device actor to be the first force component
			//if (deviceWasSecond)
			//{
			//	auto tempForceComp = forceComponent1;
			//	forceComponent1 = forceComponent2;
			//	forceComponent2 = tempForceComp;

			//	auto tempCollDetComp = FirstCollDetStaticMeshComponent;
			//	FirstCollDetStaticMeshComponent = SecondCollDetStaticMeshComponent;
			//	SecondCollDetStaticMeshComponent = tempCollDetComp;
			//}

		}

		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*																	  Calculate Restitution  						     								 */
		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/

#pragma region SynchronizedIntersectionUse

		intersectionDataLock.lock();

		std::pair<FString, double> OverlapString;
		std::pair<Force, Force> BasicForceFeedback;

		// Unwrap the pointer and access sphere nodes directly.
		if (std::get<2>(PossibleCollisionTupel[i]) && std::get<2>(PossibleCollisionTupel[i])->spherenodeisecdata)
		{
			/* Get computed forces from Hestermann algorithm */
			BasicForceFeedback = UBasicForceFeedbackCalculation::ComputeForceFeedbackPair(
				*forceComponent1,
				std::get<0>(PossibleCollisionTupel[i])->GetCollDetMatrix(),
				std::get<0>(PossibleCollisionTupel[i])->GetAttachParent()->GetComponentLocation(),
				*forceComponent2,
				std::get<1>(PossibleCollisionTupel[i])->GetCollDetMatrix(),
				std::get<1>(PossibleCollisionTupel[i])->GetAttachParent()->GetComponentLocation(),
				*(std::get<2>(PossibleCollisionTupel[i])->spherenodeisecdata),
				&OverlapString,
				true);

			CurrentSphereIntersectionCount = std::get<2>(PossibleCollisionTupel[i])->spherenodeisecdata->size();
			LastSphereIntersectionCount = CurrentSphereIntersectionCount;

			if (bTrackCollisionStats)
			{
				AmountOfCollisionTicks++;
				SecondsOfCollisions += forceComponent1->HapticDeltaTime;
			}
		}
		else
		{
			CurrentSphereIntersectionCount = 0;
		}
		intersectionDataLock.unlock();



#pragma endregion SynchronizedIntersectionUse

		RestitutionVector = FVector{
			BasicForceFeedback.first.restitution[0],
			BasicForceFeedback.first.restitution[1],
			BasicForceFeedback.first.restitution[2] };

		if (RestitutionVector.SizeSquared() == 0)
		{
			// a zero restitution force was computated, meaning no nontrivial overlaps were found
			std::get<2>(PossibleCollisionTupel[i]) = nullptr; //reset the lastCollisionData
		}

		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*                                                         Get Target and Real Device location                                                           */
		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/

		// Get Target Device Location
		PrevTickVirtualDeviceLocation = std::get<0>(PossibleCollisionTupel[i])->GetUnrealMatrix().GetLocation();

		// Get Real Device Location
		PrevTickDeviceLocation = forceComponent1->DeviceLocation;
		PrevTickDeviceRotation = forceComponent1->DeviceRotation;

		if (bApplyAccumulation)
		{
			ApplyAccumulation(RestitutionVector, RestitutionForceBuffers[forceComponent1->id], MaxRestitutionForceBufferSize);

			ApplyAccumulation(PrevTickDeviceLocation, DeviceLocationBuffers[forceComponent1->id], DeviceLocationBufferSize);

			ApplyAccumulation(PrevTickVirtualDeviceLocation, VirtualDeviceLocationBuffers[forceComponent1->id], VirtualDeviceLocationBufferSize);

			if (!bUseDeviceSpringForce && bUseNonHapticDeviceResistance)
			{
				ApplyAccumulation(PrevTickVirtualPhaseDeviceLocation, VirtualPhaseDeviceLocationBuffers[forceComponent1->id], VirtualDeviceLocationBufferSize);
			}
		}

		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*																	  Displacement  																	 */
		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/

		DisplacementVector = PrevTickDeviceLocation - PrevTickVirtualDeviceLocation;

		// if distance is smaller than intended, use no distance
		if (DisplacementVector.Size() < MinimalAllowedDistanceForComputation)
		{
			DisplacementVector = FVector::ZeroVector;
		}

		SpringVector = GetSpringVector(forceComponent1, DisplacementVector, forceComponent1->PrevTickVelocityVector);

		if (bApplyAccumulation)
		{
			ApplyAccumulation(SpringVector, SpringForceBuffer, MaxSpringForceBufferSize);
		}

		// apply saturation (a maximum length of the vectors) to balance the ratio between the two vectors in the extreme, so we don't clip through solid objects
		if (bApplySaturation)
		{
			if (RestitutionVector.SizeSquared() > 0)
			{
				RestitutionVector = RestitutionVector.GetClampedToMaxSize(ContactSaturation);

				// crucially, we do not apply saturation to the spring if no collision is occuring,
				// because this makes normal non collision movement feel awkward.
				// this does not lead to being able to clip through objects
				SpringVector = SpringVector.GetClampedToMaxSize(SpringSaturation);
			}
		}

		ThisTickVelocityVector = CalculateNewVelocityVector(forceComponent1, RestitutionVector, SpringVector);

		// Write calculated velocity vector back to the force component for the next Tick
		forceComponent1->PrevTickVelocityVector = ThisTickVelocityVector;

		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*                                                         Set location and Rotation																	 */
		/*-------------------------------------------------------------------------------------------------------------------------------------------------------*/

		if (bUseVirtualCoupling)
		{
			// set location and rotation for the virtual object according to the virtual coupling
			NewVirtualDeviceLocation = PrevTickVirtualDeviceLocation + ThisTickVelocityVector;
			NewVirtualDeviceRotation = (bAllowVirtualRotation ? PrevTickDeviceRotation : FRotator::ZeroRotator);



			std::get<0>(PossibleCollisionTupel[i])->SetCollDetActorLocationAndRotation(NewVirtualDeviceLocation, NewVirtualDeviceRotation); /// virtual coupled


			FVector OutputSpring = FVector::ZeroVector;

			if (bUseDeviceSpringForce)
			{
				//UE_LOG(LogTemp, Log, TEXT("Hello there"));
				OutputSpring = (-SpringVector * DeviceSpringForceDamper);
			}
			else if (bUseNonHapticDeviceResistance)
			{
				// add non haptic resistance when force feedback is disabled
				//UE_LOG(LogTemp, Log, TEXT("Hell mo"));
				PhaseDisplacementVector = PrevTickDeviceLocation - PrevTickVirtualPhaseDeviceLocation;

				PhaseSpringVector = GetSpringVector(forceComponent1, PhaseDisplacementVector, PrevTickPhaseVelocityVector);

				if (bApplyAccumulation)
				{
					ApplyAccumulation(PhaseSpringVector, PhaseSpringForceBuffer, MaxSpringForceBufferSize);
				}

				// spring saturation is not necessary, since we only apply it while colliding, and the phase object is not allowed to collide

				PrevTickPhaseVelocityVector = CalculateNewVelocityVector(forceComponent1, FVector::ZeroVector, PhaseSpringVector);

				PrevTickVirtualPhaseDeviceLocation = PrevTickVirtualPhaseDeviceLocation + PrevTickPhaseVelocityVector;

				OutputSpring = (-PhaseSpringVector * DeviceSpringForceDamper);
			}

			// this was a hack that would allow to increase the DeviceSpringForceDamper a bit more
			// the force for movement was still too much while no collision occured, so this added a semi smooth way of reducing it
			/*
			if (RestitutionVector.SizeSquared() == 0 || (!bUseDeviceSpringForce && bUseNonHapticDeviceResistance))
			{
				OutputSpring *= 0.75;
			}
			*/

			// Store the calculated force in the haptics manager for working on it afterwards
			//UE_LOG(LogTemp, Log, TEXT("X: %f"), OutputSpring.X);
			//UE_LOG(LogTemp, Log, TEXT("Y: %f"), OutputSpring.Y);
			//UE_LOG(LogTemp, Log, TEXT("Z: %f"), OutputSpring.Z);
			StoreForce(*forceComponent1, OutputSpring, FVector(0));
		}
		else
		{
			std::get<0>(PossibleCollisionTupel[i])->SetCollDetActorLocationAndRotation(PrevTickDeviceLocation, PrevTickDeviceRotation); /// direct rendered

			// Store the calculated force in the haptics manager for working on it afterwards
			StoreForce(*forceComponent1, RestitutionVector, FVector(0)); ///direct Rendering
		}
	}
	//intersectionDataLock.unlock();
}

void AHapticsEventHandler::ApplyAccumulation(
	FVector& VectorToUpdate,
	std::vector<FVector>& BufferToUpdate,
	uint32 MaxBufferSize)
{
	if (MaxBufferSize <= 1)
	{
		return;
	}

	BufferToUpdate.push_back(VectorToUpdate);

	if (BufferToUpdate.size() > MaxBufferSize)
	{
		// Delete the first (oldest) item from the buffer
		BufferToUpdate.erase(BufferToUpdate.begin());
	}

	FVector Sum = std::accumulate(BufferToUpdate.begin(), BufferToUpdate.end(), FVector::ZeroVector);

	VectorToUpdate = Sum / BufferToUpdate.size();
}

FVector AHapticsEventHandler::CalculateNewVelocityVector(
	UForceComponent* forceComponent1,
	FVector RestitutionVector,
	FVector SpringVector)
{
	/// idea: v_delta = t_delta * m^(-1) * a
	return ((RestitutionVector + SpringVector) * (forceComponent1->HapticDeltaTime / forceComponent1->Mass));
}

FVector AHapticsEventHandler::GetSpringVector(
	UForceComponent* forceComponent1,
	FVector DisplacementVector,
	FVector VelocityVector)
{
	if (DisplacementVector.Size() > forceComponent1->Sensitivity)
	{
		return (forceComponent1->k * DisplacementVector) - (forceComponent1->b * VelocityVector);
	}
	else
	{
		return FVector::ZeroVector;
	}
}

/// <summary>
/// Stores the force in the associated HapticsManager
/// </summary>
/// <param name="InForceComponent">The force component.</param>
/// <param name="force">The force.</param>
void AHapticsEventHandler::StoreForce(UForceComponent& InForceComponent, const FVector RestitutionForce, const FVector TorqueForce)
{
	if (InForceComponent.ForceType == EForceType::STATIC)
	{
		return;
	}

	if (AssociatedHapticsManager)
	{
		AssociatedHapticsManager->ForcesOfNextTick[InForceComponent.id] = AHapticsManager::TranslateBetweenUnrealAndHapticVector(RestitutionForce);

		AssociatedHapticsManager->TorquesOfNextTick[InForceComponent.id] = AHapticsManager::TranslateBetweenUnrealAndHapticVector(TorqueForce);

		//AssociatedHapticsManager->ForceOfNextTick = 
		//	AHapticsManager::TranslateBetweenUnrealAndHapticVector(RestitutionForce);

		//AssociatedHapticsManager->TorqueOfNextTick =
		//	AHapticsManager::TranslateBetweenUnrealAndHapticVector(TorqueForce);

		//AssociatedHapticsManager->componentID = InForceComponent.id;
	}
}

/// <summary>
/// Vectors to csv FString converter.
/// xyz vector will be converted to "x, y, z".
/// </summary>
/// <param name="InVector">The vector.</param>
/// <returns></returns>
FString AHapticsEventHandler::VectorToCSV(FVector InVector)
{
	return FString::Printf(TEXT("%+12.4f,%+12.4f,%+12.4f"), InVector.X, InVector.Y, InVector.Z);
}

/// <summary>
/// Handler for the OAfterCalibratingDevice delegate.
/// Starts the ticking of this actor.
/// </summary>
void AHapticsEventHandler::HandleAfterCalibratingDevice()
{
	bDeviceIsCalibrated = true;

#pragma region Debugging
	SetActorTickEnabled(true);	// for debug draws
#pragma endregion Debugging
}

#pragma region DebugDraws
void AHapticsEventHandler::DrawDebugInfo()
{
	// Device Location
	{
		DrawDebugCrosshairs(
			GetWorld(), // const UWorld* InWorld,
			PrevTickDeviceLocation, // FVector const& AxisLoc,
			FRotator::ZeroRotator, //FRotator const& AxisRot,
			20, // float Scale,
			FColor::Orange, // const FColor& Color = FColor::White,  //pink
			false // bool bPersistentLines = false,
				  // 0.03f, //float LifeTime = -1.f,
				  // 0 // uint8 DepthPriority = 0
		);
		DrawDebugString(
			GetWorld(),
			PrevTickDeviceLocation + FVector(1),
			"Device",
			(AActor*)0,
			FColor::Orange,
			0.0f
		);
	}

	// Device Offset
	{
		DrawDebugCrosshairs(
			GetWorld(), // const UWorld* InWorld,
			AssociatedHapticsManager->CalibratedDeviceOffset.GetLocation(), // FVector const& AxisLoc,
			FRotator(10, 10, 10), //FRotator const& AxisRot,
			20, // float Scale,
			FColor::Red, // const FColor& Color = FColor::White,  //pink
			false // bool bPersistentLines = false,
				  // 0.03f, //float LifeTime = -1.f,
				  // 0 // uint8 DepthPriority = 0
		);
		DrawDebugString(
			GetWorld(),
			AssociatedHapticsManager->CalibratedDeviceOffset.GetLocation() + FVector(1),
			"DeviceOffset",
			(AActor*)0,
			FColor::Red,
			0.0f
		);
	}

	// Target Device Location
	{
		DrawDebugCrosshairs(
			GetWorld(), // const UWorld* InWorld,
			PrevTickVirtualDeviceLocation + FVector(0.2), // FVector const& AxisLoc,
			FRotator(20, 20, 20), //FRotator const& AxisRot,
			10, // float Scale,
			FColor::Blue, // const FColor& Color = FColor::White, //blue
			false // bool bPersistentLines = false,
				  // 0.03f, //float LifeTime = -1.f,
				  // 0 // uint8 DepthPriority = 0
		);
		DrawDebugString(
			GetWorld(),
			PrevTickVirtualDeviceLocation + FVector(1),
			"Virtual Device",
			(AActor*)0,
			FColor::Blue,
			0.0f
		);
	}

	// DisplacementVector
	{
		DrawDebugDirectionalArrow(
			GetWorld(), // const UWorld* InWorld,
			PrevTickVirtualDeviceLocation,
			PrevTickVirtualDeviceLocation + DisplacementVector, // FVector const& AxisLoc,
			10, // float Scale,
			FColor::Blue, // const FColor& Color = FColor::White, //blue
			false // bool bPersistentLines = false,
				  // 0.03f, //float LifeTime = -1.f,
				  // 0 // uint8 DepthPriority = 0
		);
		DrawDebugString(
			GetWorld(),
			PrevTickVirtualDeviceLocation + DisplacementVector / 2, // + FVector(1),
			"Displacement",
			(AActor*)0,
			FColor::Blue,
			0.03f
		);
	}

	// RestitutionVector
	if (RestitutionVector != FVector::ZeroVector)
	{
		DrawDebugDirectionalArrow(
			GetWorld(), // const UWorld* InWorld,
			PrevTickVirtualDeviceLocation,
			PrevTickVirtualDeviceLocation + RestitutionVector, // FVector const& AxisLoc,
			10, // float Scale,
			FColor::Purple, // const FColor& Color = FColor::White, //blue
			false // bool bPersistentLines = false,
					// 0.03f, //float LifeTime = -1.f,
					// 0 // uint8 DepthPriority = 0
		);
		//DrawDebugString(
		//	GetWorld(),
		//	PrevTickVirtualDeviceLocation + RestitutionVector / 2, // + FVector(1),
		//	"Restitution",
		//	(AActor*)0,
		//	FColor::Purple,
		//	0.f
		//);
	}

	// SpringVector
	if (SpringVector != FVector::ZeroVector)
	{
		DrawDebugDirectionalArrow(
			GetWorld(), // const UWorld* InWorld,
			PrevTickVirtualDeviceLocation,
			PrevTickVirtualDeviceLocation + SpringVector, // FVector const& AxisLoc,
			10, // float Scale,
			FColor::Green, // const FColor& Color = FColor::White, //blue
			false // bool bPersistentLines = false,
				  // 0.03f, //float LifeTime = -1.f,
				  // 0 // uint8 DepthPriority = 0
		);
		//DrawDebugString(
		//	GetWorld(),
		//	SpringVector / 2, // + FVector(1),
		//	"SpringVector",
		//	(AActor*)0,
		//	FColor::Green,
		//	0.f
		//);
	}
}
#pragma endregion DebugDraws