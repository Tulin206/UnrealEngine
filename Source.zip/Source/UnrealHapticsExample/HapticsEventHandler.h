// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include <ColletteStaticMeshComponent.h>
#include "ColletteManager.h"
#include "HapticsManager.h"
#include "ForceComponent.h"

#include <utility>
#include <mutex>

#include "ForceComponent.h"
#include "BasicForceFeedbackCalculation.h"
#include "HapticsManager.h"

#include "Core.h"

DECLARE_LOG_CATEGORY_EXTERN(LogHapticsEventHandler, All, All)

#include "HapticsEventHandler.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FButton1Clicked);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FButton2Clicked);


/*
	This Class takes care of threaded movement of the a player actor
	with a ColletteStaticMeshComponent through a haptic device.
	It binds the relevant functions to the desired (Delegate)Event
	This is an example how the HapticManager can be used to move an Actor

	Info:
	The CollDetStaticMeshComponent is to be found in the CollettePlugin
	It has a separate transform (of type Vectormath::Aos::Matrix4)
	which gets updated by the thread, and the game tick then uses the
	updated second transform to update the main transform of the RootComponent.
*/
UCLASS(autoExpandCategories = Controller,
	hideCategories = ("Transform", "Rendering", "Actor", "HLOD", "Input"))
	class AHapticsEventHandler : public AActor
{
	GENERATED_BODY()

public:

	// Sets default values for this actor's properties
	AHapticsEventHandler();

	~AHapticsEventHandler();

	virtual void Tick(float DeltaTime) override;

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void EndPlay(EEndPlayReason::Type reason);

	// Functions for broadcasting the button delegates

	UFUNCTION()
		void OnButton1Clicked();

	UFUNCTION()
		void OnButton2Clicked();

public:

	/* The actor object that the haptic device is supposed to move */
	UPROPERTY(EditAnywhere, Category = "Controller")
		AActor* DeviceActor;

	UPROPERTY(EditAnywhere, Category = "Controller")
		TEnumAsByte<SupportedDevices> Device;

	/* The ColletteManager in the scene. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Controller", meta = (DisplayName = "ColletteManager"))
		AColletteManager* ColletteManager;

	/* The HapticsManager needed for Haptic Devices and Haptic Force Feedback */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Controller", meta = (DisplayName = "HapticsManager"))
		AHapticsManager* AssociatedHapticsManager;

	/* With virtual coupling, a virtual device location will attempt to follow the device location, but get stuck at obstacles */
	UPROPERTY(EditAnywhere, Category = "Controller")
		bool bUseVirtualCoupling = true;

	/* Whether to copy the device rotation to the virtual device object.
		Since torque is not implemented, this is a 'teleportation', so it messes with collisions and allows you to phase through objects */
	UPROPERTY(EditAnywhere, Category = "Controller", meta = (EditCondition = "bUseVirtualCoupling"))
		bool bAllowVirtualRotation = false;

	/* Decides whether to draw debug arrows for values like displacement and restitution during runtime */
	UPROPERTY(EditAnywhere, Category = "Controller")
		bool bDrawDebugArrows = false;

	/* Whether to send the calculated force to the device. If disabled, the plugins can still be used for virtual coupling or similar.
	   If disabled you can still apply non haptic resistance if bUseNonHapticDeviceResistance is enabled. */
	UPROPERTY(EditAnywhere, Category = "Device Force")
		bool bUseDeviceSpringForce = true;

	/* Factor that only gets applied to the force that is sent to the device, not applied to the virtual position calculation.
		This will be a bit different for every device. For example the Novint Falcon feels good with values around 0.015, the Phantom Omni around 0.005 */
	UPROPERTY(EditAnywhere, Category = "Device Force")
		double DeviceSpringForceDamper = 0.005;

	/* Sends a minor amount of force to the device when moving it, even when bUseDeviceSpringForce is disabled.
		Since force feedback is never zero while moving the device, even when not colliding with anything,
		completely disabling it would drastically change how using the device feels.
		This force is completely independent of ingame collisions, solely based on how the device moves in real life.
	*/
	UPROPERTY(EditAnywhere, Category = "Device Force", meta = (EditCondition = "!bUseDeviceSpringForce"))
		bool bUseNonHapticDeviceResistance = true;

	/* Whether to apply saturation (a maximum length of the vectors) to balance the ratio between the spring and restitution vector in the extreme,
		so we don't clip through solid objects */
	UPROPERTY(EditAnywhere, Category = "Saturation")
		bool bApplySaturation = true;

	/* Used along with ContactSaturation to build a ratio between spring force and restitution force while one or both are quite high.
	Acts as a maximum length of the vector */
	UPROPERTY(EditAnywhere, Category = "Saturation", meta = (EditCondition = "bApplySaturation"))
		double SpringSaturation = 300;

	/* Used along with SpringSaturation to build a ratio between spring force and restitution force while one or both are quite high.
	Acts as a maximum length of the vector */
	UPROPERTY(EditAnywhere, Category = "Saturation", meta = (EditCondition = "bApplySaturation"))
		double ContactSaturation = 500;

	/* Whether to accumulate the values of the past few frames for relevant data points and then apply a simple weighting.
		This reduces noise if the buffer sizes are set appropriately */
	UPROPERTY(EditAnywhere, Category = "Accumulation Buffers")
		bool bApplyAccumulation = true;

	UPROPERTY(EditAnywhere, Category = "Accumulation Buffers", meta = (EditCondition = "bApplyAccumulation", ClampMin = 1, UIMin = 1))
		uint32 VirtualDeviceLocationBufferSize = 5;

	UPROPERTY(EditAnywhere, Category = "Accumulation Buffers", meta = (EditCondition = "bApplyAccumulation", ClampMin = 1, UIMin = 1))
		uint32 DeviceLocationBufferSize = 5;

	UPROPERTY(EditAnywhere, Category = "Accumulation Buffers", meta = (EditCondition = "bApplyAccumulation", ClampMin = 1, UIMin = 1))
		uint32 MaxRestitutionForceBufferSize = 5;

	UPROPERTY(EditAnywhere, Category = "Accumulation Buffers", meta = (EditCondition = "bApplyAccumulation", ClampMin = 1, UIMin = 1))
		uint32 MaxSpringForceBufferSize = 1;

	/* If displacement movement this frame was smaller than this, then it will be assumed to be zero. This is usually not needed for most haptic devices */
	UPROPERTY(EditAnywhere, Category = "Controller")
		double MinimalAllowedDistanceForComputation = 0;

	/* Delegates for Button 1 of the haptic device defined through the Chai3D framework */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Controller")
		FButton1Clicked OnActionButton1Clicked;

	/* Delegates for Button 2 of the haptic device defined through the Chai3D framework */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Controller")
		FButton2Clicked OnActionButton2Clicked;

private:

	// triggered through delegate
	void HandleNewHapticData(const FHapticData& data);

	// triggered through delegate
	void HandleAfterCalibratingDevice();

	// triggered through delegate
	void HandleCollision(
		UColletteStaticMeshComponent& InFirstCollDetStaticMeshComponent,
		UColletteStaticMeshComponent& InSecondCollDetStaticMeshComponent,
		const col::Data* const collisionData);

	// triggered through delegate
	void HandleForceFeedbackCalculation();

	void StoreForce(UForceComponent& target, const FVector RestitutionForce, const FVector TorqueForce);

	void ApplyAccumulation(
		FVector& VectorToUpdate,
		std::vector<FVector>& BufferToUpdate,
		uint32 MaxBufferSize);

	static FVector CalculateNewVelocityVector(
		UForceComponent* forceComponent1,
		FVector RestitutionVector,
		FVector SpringVector);

	static FVector GetSpringVector(
		UForceComponent* forceComponent1,
		FVector DisplacementVector,
		FVector VelocityVector);

	FString VectorToCSV(FVector v);

	void DrawDebugInfo();

public:

	UPROPERTY(BlueprintReadOnly)
		bool bTrackCollisionStats;

	UPROPERTY(BlueprintReadOnly)
		double SecondsOfCollisions;

	UPROPERTY(BlueprintReadOnly)
		int64 AmountOfCollisionTicks;

	UPROPERTY(BlueprintReadOnly)
		int32 CurrentSphereIntersectionCount;

	UPROPERTY(BlueprintReadOnly)
		int32 LastSphereIntersectionCount;

private:

	// reference to the force component that was attached to the device actor
	UForceComponent* DeviceForceComponent;

	TArray<UForceComponent*> DeviceContactPoints;

	TArray<UColletteStaticMeshComponent*> CollMeshes;

#pragma region Mutex
	std::mutex intersectionDataLock;
#pragma endregion Mutex

	bool bDeviceIsCalibrated = false;

	// holds the first collision partner when a collision occurs
	UColletteStaticMeshComponent* FirstCollDetStaticMeshComponent;
	// holds the first collision partner when a collision occurs
	UColletteStaticMeshComponent* SecondCollDetStaticMeshComponent;
	// holds the collision data when a collision occurs
	const col::Data* lastCollisionData;

	std::vector<std::tuple<UColletteStaticMeshComponent*, UColletteStaticMeshComponent*, const col::Data*>> PossibleCollisionTupel;

	//---- Parameters for force calculation ----//

	// location of the (real) device
	FVector PrevTickDeviceLocation;
	FRotator PrevTickDeviceRotation;

	// location of the virtual device
	FVector PrevTickVirtualDeviceLocation;
	// there is no virtual rotation variable since torque is not implemented

	FVector PrevTickVirtualPhaseDeviceLocation;

	FVector NewVirtualDeviceLocation;
	FRotator NewVirtualDeviceRotation;

	// Displacement vector between the virtual and real location
	FVector DisplacementVector;
	FVector PhaseDisplacementVector;

	// Restitution vector (R�Eksetzvektor)
	FVector RestitutionVector;

	//std::vector<FVector> RestitutionForceBuffer;	

	std::vector<FVector> SpringForceBuffer;
	std::vector<FVector> PhaseSpringForceBuffer;

	std::vector<FVector> VirtualDeviceLocationBuffer;
	std::vector<FVector> VirtualPhaseDeviceLocationBuffer;

	std::vector<FVector> DeviceLocationBuffer;

	std::vector<std::vector<FVector>> RestitutionForceBuffers;
	std::vector<std::vector<FVector>> DeviceLocationBuffers;
	std::vector<std::vector<FVector>> VirtualDeviceLocationBuffers;
	std::vector<std::vector<FVector>> VirtualPhaseDeviceLocationBuffers;

	// Calculated force of the spring due to displacement and velocity
	FVector SpringVector;

	FVector PhaseSpringVector;

	FVector PrevTickVelocityVector;

	FVector PrevTickPhaseVelocityVector;

	FVector ThisTickVelocityVector;
};
