# Add to project
Create a `Plugins` folder in your project, then add the plugin as a submodule or create a subfolder and manually copy this content.

## With git submodule
External users need to adapt the URL from `git@` to `https://`. In project root directory (.uproject) run:
```
git submodule add git@gitlab.informatik.uni-bremen.de:cgvr_public/haptico.git Plugins/Haptico
```

# Install
- Add "Haptico" to <project>.Build.cs public dependencie modules:
  E.g.: PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "Haptico" });