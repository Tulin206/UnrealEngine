#include "HapticoKinesCeti.h"
#include "SerialPort.h"
#include "chai3d.h"
#include "HapticoGlove.h"
#include "Math/Vector.h" 

using namespace chai3d;

HapticoKinesCeti::HapticoKinesCeti()
{
    //initializeFingerVectors();
}

HapticoKinesCeti::~HapticoKinesCeti()
{
}

bool HapticoKinesCeti::open()
{
    UE_LOG(LogTemp, Warning, TEXT("open function called"));
    // return (*leapDevice)->open();

    if (arduino.isConnected()) {
        std::cout << "Arduino is connected" << std::endl;
        UE_LOG(LogTemp, Log, TEXT("Arduino is connected!"));
        return (*leapDevice)->open();
    }
    else {
        UE_LOG(LogTemp, Warning, TEXT("Arduino is not connected!"));
        std::cout << "Arduino is not connected" << std::endl;
        return false;
    }
}

bool HapticoKinesCeti::close()
{
    UE_LOG(LogTemp, Warning, TEXT("Close function called"));
    if (arduino.isConnected()) {
        std::cout << "Arduino connection closed" << std::endl;
        UE_LOG(LogTemp, Warning, TEXT("Arduino connection closed"));
        arduino.~SerialPort();     // Explicitly close the serial port connection
        return true;
    }
    else {
        UE_LOG(LogTemp, Warning, TEXT("Arduino is not connected!"));
        return true;
    }
}

void HapticoKinesCeti::disconnect()
{
    UE_LOG(LogTemp, Warning, TEXT("disconnect function called"));
    (*leapDevice)->~cGenericHapticDevice();
    (*leapDevice).~shared_ptr();
    delete leapDevice;
}

bool HapticoKinesCeti::calibrate(bool calibrate) {
    UE_LOG(LogTemp, Warning, TEXT("Calibrate function called"));

    // Print the value of nSensors
    UE_LOG(LogTemp, Log, TEXT("nSensors: %d"), nSensors);

    // added by ISRAT
    // // If we are calibrating, set initial values
    prerawFingerData[0] = rawFingerData[0];
    prerawFingerData[1] = rawFingerData[1];

    // Reseting calibration values
    counter[0] = 0;
    counter[1] = 0;
    Ucounter[0] = 0;
    Ucounter[1] = 0;
    maxVal[0] = -100000;
    maxVal[1] = -100000;
    minVal[0] = 100000;
    minVal[1] = 100000;
    calVal = 0;
    DCal = 0;
    ////////////////////////////////////////////

    //for (int d = 0; d < nSensors; d++) {
    //    DCal = rawFingerData[d] - prerawFingerData[d];

    //    // Use the helper function to update the counter
    //    updateCounter(d, DCal);

    //    if (counter[d] > Ucounter[d]) {
    //        Ucounter[d] = counter[d];
    //    }

    //    // Update min and max values
    //    updateMinMaxValues(d);

    //    prerawFingerData[d] = rawFingerData[d];

    //    // Print the values of prerawFingerData[d] and rawFingerData[d]
    //    UE_LOG(LogTemp, Log, TEXT("prerawFingerData[%d] = %f, rawFingerData[%d] = %f"), d, prerawFingerData[d], d, rawFingerData[d]);
    //}
    return true;
}

void HapticoKinesCeti::updateCounter(int FingerID, double deltaCal) {
    UE_LOG(LogTemp, Warning, TEXT("updateCounter function called"));
    if (deltaCal > 0) {
        if (deltaCal > (4095 - rawFingerData[FingerID] + prerawFingerData[FingerID])) {
            counter[FingerID] -= 1;
        }
    }
    else if (deltaCal < 0) {
        deltaCal = -deltaCal; // Make DCal positive
        if (deltaCal > (4095 - prerawFingerData[FingerID] + rawFingerData[FingerID])) {
            counter[FingerID] += 1;
        }
    }
}

void HapticoKinesCeti::updateMinMaxValues(int d) {
    UE_LOG(LogTemp, Warning, TEXT("updateMinMaxValues function called"));

    // Adjust the min and max values based on calibrated values
    if (counter[d] < 0) {
        counter[d] += 1;
        Ucounter[d] += 1;
        minVal[d] = rawFingerData[d];
        maxVal[d] += 4905 - minVal[d];
    }

    calVal = rawFingerData[d] + 4095 * counter[d];
    UE_LOG(LogTemp, Log, TEXT("DCal: %f, Counter: [%f, %f], Ucounter: [%f, %f], CalVal: %f"),
        DCal, counter[0], Ucounter[0], Ucounter[1], counter[1], calVal);

    if (calVal > maxVal[d]) {
        maxVal[d] = calVal;
        UE_LOG(LogTemp, Log, TEXT("Finger %d - Max Value: %f"), d, maxVal[d]);
    }
    if (calVal < minVal[d]) {
        minVal[d] = calVal;
        UE_LOG(LogTemp, Log, TEXT("Finger %d - Min Value: %f"), d, minVal[d]);
    }
}

std::vector<FVector> HapticoKinesCeti::getPositions() {
    UE_LOG(LogTemp, Warning, TEXT("getPosition function called"));

    readSensorData();               // Ensure sensor data is up-to-date
    initializeFingerVectors();     // set up the initial positions and transformations of the fingers relative to the hand.
    applyHandTransformations();   // apply transformations based on the latest hand position and rotation obtained from the sensors.
    calculateFingerTransforms(); // applies specific transformations to calculate the positions of individual finger joints.

    std::vector<FVector> positions = {};
    positions.push_back(FVector(handPosition.x(), handPosition.y(), handPosition.z()));
    //positions.push_back(FVector(0, 0, 0));
    UE_LOG(LogTemp, Log, TEXT("Hand Position: %f, %f, %f"), handPosition.x(), handPosition.y(), handPosition.z());

    positions.push_back(FVector(thTrf.getLocalPos().x(), thTrf.getLocalPos().y(), thTrf.getLocalPos().z()));
    UE_LOG(LogTemp, Log, TEXT("Thumb LocalPos: %f, %f, %f"), thTrf.getLocalPos().x(), thTrf.getLocalPos().y(), thTrf.getLocalPos().z());


    //positions.push_back(FVector(-idxTrf.getLocalPos().x(), -idxTrf.getLocalPos().y(), -idxTrf.getLocalPos().z()));
    positions.push_back(FVector(idxTrf.getLocalPos().x(), idxTrf.getLocalPos().y(), idxTrf.getLocalPos().z()));
    //positions.push_back(FVector(handPosition.x(), handPosition.y(), handPosition.z()));
    UE_LOG(LogTemp, Log, TEXT("Index LocalPos: %f, %f, %f"), idxTrf.getLocalPos().y(), idxTrf.getLocalPos().z());

    return positions;
}

std::vector<FMatrix> HapticoKinesCeti::getRotations()
{
    std::vector<FMatrix> result = {};
    (*leapDevice)->getRotation(rotation);

    //rotation.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 180);

    result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
        FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
        FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
        FVector(0, 0, 0)));
    result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
        FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
        FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
        FVector(0, 0, 0))); 
    result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
        FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
        FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
        FVector(0, 0, 0)));

    return result;
}

void HapticoKinesCeti::readSensorData() {
    UE_LOG(LogTemp, Warning, TEXT("readSensorData function called"));

    // Receiving message by serial port //
    char valchar[256];
    int result = arduino.readSerialPort(valchar, sizeof(valchar));
    // result = arduino.readSerialPort(valchar, 256);

    // Log the result code
    UE_LOG(LogTemp, Log, TEXT("Result code from readSerialPort: %d"), result);

    // If no data was received, Log the error
    if (result == 0) {
        UE_LOG(LogTemp, Error, TEXT("Failed to read data from serial port. Using default values."));

        //// Set a safe default data string
        //strcpy(valchar, "0.1,0.2,0.3,0.4,0.5,0.6,0.7");
        //UE_LOG(LogTemp, Log, TEXT("Using default data: %s"), *FString(valchar));
    }
    else {
        // If data was successfully read, log the received data
        UE_LOG(LogTemp, Log, TEXT("Received data: %s"), *FString(valchar));
    }

    // Ensure we are not working with corrupted data
    if (strlen(valchar) > 0 && strlen(valchar) < sizeof(valchar)) {
        parseSerialData(valchar);
    }
    else {
        UE_LOG(LogTemp, Error, TEXT("Received malformed or empty data. Skipping parse."));
    }
}

/// added by ISRAT///
void HapticoKinesCeti::parseSerialData(const char* valchar) {
    UE_LOG(LogTemp, Warning, TEXT("parseSerialData function called"));

    std::string data(valchar);

    // Step 1: Split data by newlines
    std::stringstream ss(data);
    std::string line;

    while (std::getline(ss, line)) {
        // Step 2: Sanitize the line
        std::string cleanedLine = "";
        for (char c : line) {
            // Acceptable characters are digits, minus sign, dot, comma, and newline
            if (isdigit(c) || c == '-' || c == '.' || c == ',' || c == '\n') {
                cleanedLine += c;
            }
        }

        // Step 3: Check if line has exactly 7 comma-separated values
        std::vector<std::string> values;
        std::string tempStr = "";
        for (char c : cleanedLine) {
            if (c == ',') {
                values.push_back(tempStr);
                tempStr = "";
            }
            else {
                tempStr += c;
            }
        }
        values.push_back(tempStr);  // Push the last value

        // Step 4: Parse only if exactly 7 values exist
        if (values.size() == 7) {
            try {
                double val0 = std::stod(values[0]);
                double val1 = std::stod(values[1]);
                double val2 = std::stod(values[2]);
                double val3 = std::stod(values[3]);
                double val4 = std::stod(values[4]);
                double val5 = std::stod(values[5]);
                double val6 = std::stod(values[6]);

                // Print parsed values for debugging
                UE_LOG(LogTemp, Log, TEXT("Parsed values: val0: %.2f, val1: %.2f, val2: %.2f, val3: %.2f, val4: %.2f, val5: %.2f, val6: %.2f"),
                    val0, val1, val2, val3, val4, val5, val6);

                // Assign parsed values to variables
                motorStatus1 = (val0 == 1) ? true : false;
                motorStatus2 = (val1 == 1) ? true : false;
                rawFingerData[0] = val2;
                rawFingerData[1] = val3;
                accX = val4;
                accY = val5;
                accZ = val6;

                // Print final values for debugging
                UE_LOG(LogTemp, Log, TEXT("motorStatus1: %d, motorStatus2: %d, rawFingerData[0]: %.2f, rawFingerData[1]: %.2f, accX: %.2f, accY: %.2f, accZ: %.2f"),
                    motorStatus1,
                    motorStatus2,
                    rawFingerData[0],
                    rawFingerData[1],
                    accX,
                    accY,
                    accZ);
            }
            catch (const std::exception& e) {
                UE_LOG(LogTemp, Error, TEXT("Exception caught during parsing: %s"), *FString(e.what()));
            }
        }
        else {
            UE_LOG(LogTemp, Error, TEXT("Error: Expected 7 values, but got %d"), values.size());
        }
    }
}

//void HapticoKinesCeti::parseSerialData(const char* valchar) {
//    //UE_LOG(LogTemp, Warning, TEXT("parseSerialData function called"));
//
//    int commaIdx[8] = { 0,0,0,0,0,0,0,0 }; // array to store the indices of commas in valchar
//    int idx = 0; // index used to track the number of parsed values.
//    double val0 = 99999999, val1 = 99999999, val2 = 99999999, val3 = 99999999, val4 = 99999999, val5 = 99999999, val6 = 99999999;
//    std::string str0 = "", str1 = "", str2 = "", str3 = "", str4 = "", str5 = "", str6 = ""; // array of strings to store the separated values
//
//    try {
//        for (int h = 0; h < strlen(valchar); h++) { // When a comma is found, its index is stored in commaIdx, and idx is incremented. The loop stops if idx reaches 7.
//            if (valchar[h] == ',') {
//                if (idx >= 8) {
//                    UE_LOG(LogTemp, Warning, TEXT("Error: Too many comma-separated values in input string."));
//                    break;
//                }
//                commaIdx[idx] = h;
//                idx++;
//            }
//            else if (idx == 0) {
//                str0 += valchar[h];
//            }
//            else if (idx == 1) {
//                str1 += valchar[h];
//            }
//            else if (idx == 2) {
//                str2 += valchar[h];
//            }
//            else if (idx == 3) {
//                str3 += valchar[h];
//            }
//            else if (idx == 4) {
//                str4 += valchar[h];
//            }
//            else if (idx == 5) {
//                str5 += valchar[h];
//            }
//            else if (idx == 6) {
//                str6 += valchar[h];
//            }
//            else if (idx > 6) {
//                break;
//            }
//        }
//
//        if (idx < 6) {
//            UE_LOG(LogTemp, Warning, TEXT("Error: Not enough comma-separated values in input string."));
//            return;
//        }
//
//        if (idx >= 6) {
//            val0 = stod(str0); // mCommand[0]
//            val1 = stod(str1); // mCommand[1]
//            val2 = stod(str2); // pos[0], Index flexion/extension
//            val3 = stod(str3); // pos[1], Thumb abduction, currently the cable is broken
//            val4 = stod(str4); // accX
//            val5 = stod(str5); // accY
//            val6 = stod(str6); // accZ
//        }
//
//        // Print parsed values before any other processing
//        //UE_LOG(LogTemp, Log, TEXT("Parsed values: val0: %.2f, val1: %.2f, val2: %.2f, val3: %.2f, val4: %.2f, val5: %.2f, val6: %.2f"),
//            //val0, val1, val2, val3, val4, val5, val6);
//
//        // Now checking if values are not null
//        if (val0 != 99999999 && val1 != 99999999 && (val2 != 99999999 || val3 != 99999999 || val4 != 99999999 || val5 != 99999999 || val6 != 99999999)) {
//            // Now updating values
//            if (val0 != 99999999 && pre_val0 != val1) pre_val0 = val0;
//            if (val1 != 99999999 && pre_val1 != val1) pre_val1 = val1;
//            if (val2 != 99999999 && pre_val2 != val2) pre_val2 = val2;
//            if (val3 != 99999999 && pre_val3 != val3) pre_val3 = val3;
//            if (val4 != 99999999 && pre_val4 != val4) pre_val4 = val4;
//            if (val5 != 99999999 && pre_val5 != val5) pre_val5 = val5;
//            if (val6 != 99999999 && pre_val6 != val6) pre_val6 = val6;
//
//            // Assigning values to the applied variables
//            motorStatus1 = (val0 == 1) ? true : false;    // Index flex
//            motorStatus2 = (val1 == 1) ? true : false;    // Thumb flex
//            rawFingerData[0] = pre_val2;    // Index flex
//            rawFingerData[1] = pre_val3;    // Thumb flex
//            accX = pre_val4;
//            accY = pre_val5;
//            accZ = pre_val6;
//
//            // Print data for debugging
//            UE_LOG(LogTemp, Log, TEXT("motorStatus1: %d, motorStatus2: %d, rawFingerData[0]: %.2f, rawFingerData[1]: %.2f, accX: %.2f, accY: %.2f, accZ: %.2f"),
//                motorStatus1,
//                motorStatus2,
//                rawFingerData[0],
//                rawFingerData[1],
//                accX,
//                accY,
//                accZ);
//        }
//    }
//    catch (const std::exception& e) {
//        UE_LOG(LogTemp, Error, TEXT("Exception caught: %s"), *FString(e.what()));
//    }
//}

void HapticoKinesCeti::initializeFingerVectors() {
    UE_LOG(LogTemp, Warning, TEXT("InitializeFingerVectors function called"));
    
    // Finger transformations
    ones.identity();      // rotation of the finger in relation to the hand

    //Index finger

    //Index finger - Vector
    idxVec00.set(0, 0, 0);
    idxVec01.set(-0.04, 0, 0); // UNITS ARE METERS, Quantities tried: 0.1, 1,  0.5

    //Thumb finger - Vector
    thVec00.set(0, 0, 0);
    thVec01.set(-0.04, 0, 0);

    idxRotOffset.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0); //Index finger - Rotation - offset
    thRotOffset.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0); //Thumb finger - Rotation - offset

    // Transform matrices
    idxTrfOffset.set(idxVec00, idxRotOffset);
    thTrfOffset.set(thVec00, thRotOffset);

    //// added by ISRAT
    for (int d = 0; d < nSensors; d++) {
        DCal = rawFingerData[d] - prerawFingerData[d];

        // Debug: Check sensor values
        UE_LOG(LogTemp, Log, TEXT("rawFingerData[%d] = %f, prerawFingerData[%d] = %f"), d, rawFingerData[d], d, prerawFingerData[d]);

        // Skip if rawFingerData is 0 to avoid setting min/max incorrectly
        if (rawFingerData[d] == 0) {
            UE_LOG(LogTemp, Warning, TEXT("Skipping sensor %d because rawFingerData is 0"), d);
            continue;
        }
        // Use the helper function to update the counter
        updateCounter(d, DCal);

        if (counter[d] > Ucounter[d]) {
            Ucounter[d] = counter[d];
        }

        // Update min and max values
        updateMinMaxValues(d);

        prerawFingerData[d] = rawFingerData[d];

        // Print the values of prerawFingerData[d] and rawFingerData[d]
        UE_LOG(LogTemp, Log, TEXT("prerawFingerData[%d] = %f, rawFingerData[%d] = %f"), d, prerawFingerData[d], d, rawFingerData[d]);
    }
}

void HapticoKinesCeti::applyHandTransformations() {
    UE_LOG(LogTemp, Warning, TEXT("applyHandTransformations function called"));

    // Read Leap Motion device data
    readLeapDevice();  // This method updates handPosition and rotation

    // Set hand position and rotations for further processing
    hand.set(handPosition, rotation);
    idxTrf.copyfrom(hand);
    thTrf.copyfrom(hand);

    // Sensor readings:  Perform finger-specific transformations
    indexMeas = fingerMeasurement(0);
    thumbMeas = fingerMeasurement(1);

    UE_LOG(LogTemp, Warning, TEXT("Index Measurement: %f"), indexMeas);
    UE_LOG(LogTemp, Warning, TEXT("Thumb Measurement: %f"), thumbMeas);

}

void HapticoKinesCeti::readLeapDevice() {
    UE_LOG(LogTemp, Warning, TEXT("readLeapDevice function called"));

    //handPosition = cVector3d(2 * handPosition.x(), 2 * handPosition.y(), 2 * handPosition.z());

    // Extract hand position and rotation from Leap Motion device
    (*leapDevice)->getPosition(handPosition);
    (*leapDevice)->getRotation(rotation);

    // Print hand position to the log
    UE_LOG(LogTemp, Log, TEXT("Hand Position: X=%f, Y=%f, Z=%f"), handPosition.x(), handPosition.y(), handPosition.z()); 
}

// Function to convert the corrected position measurements to degrees
double HapticoKinesCeti::fingerMeasurement(int FingerID) {
    UE_LOG(LogTemp, Warning, TEXT("fingerMeasurement function called"));

    // Correction of data
    double OldValue = 0;
    DCal = rawFingerData[FingerID] - prerawFingerData[FingerID];

    // Use helper function to update the counter
    updateCounter(FingerID, DCal);

    // Check if calibration error occurred
    // If the measurements go out of the limits calibration is needed again
    if (counter[FingerID] > Ucounter[FingerID] || counter[FingerID] < 0) {
        std::cout << "Calibration error" << std::endl;
        UE_LOG(LogTemp, Warning, TEXT("Calibration error for FingerID %d"), FingerID);
    }

    // Now let's rectify everything if counter is negative
    prerawFingerData[FingerID] = rawFingerData[FingerID];
    OldValue = rawFingerData[FingerID] + 4095 * counter[FingerID];

    // Range conversion
    double OldRange = (maxVal[FingerID] - minVal[FingerID]);
    double NewRange = 100;

    // Check to avoid division by zero
    if (OldRange <= 0) {
        UE_LOG(LogTemp, Warning, TEXT("Invalid OldRange: %f for FingerID %d"), OldRange, FingerID);
        return 0.0;  // Return a default or error value
    }

    // Return the scaled value
    double result = (((OldValue - minVal[FingerID]) * NewRange) / OldRange) + 0;

    // Check for valid result
    if (std::isinf(result)) {
        //UE_LOG(LogTemp, Warning, TEXT("Result is infinite for FingerID %d"), FingerID);
        return 0.0;  // Or handle this error appropriately
    }

    return result;
}

void HapticoKinesCeti::calculateFingerTransforms() {
    UE_LOG(LogTemp, Warning, TEXT("calculateFingerTransforms function called"));

    // Set FInger Rotation
    //idxRot01.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 180 + indexMeas);
    //thRot01.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 180 - thumbMeas);
    idxRot01.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0 + indexMeas);  // ISRAT
    thRot01.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0 + thumbMeas);

    //// Set Finger Matrices
    //idxTrf01.set(idxVec00, idxRot01);
    //idxTrf12.set(idxVec01, idxRot12);
    //thTrf01.set(thVec00, thRot01);
    //thTrf12.set(thVec01, thRot12);

    // Set Finger Matrices (added by israt)
    idxRot12.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0);
    idxTrf01.set(idxVec00, idxRot01);
    idxTrf12.set(idxVec01, idxRot12);

    thRot12.setAxisAngleRotationDeg(cVector3d(0, 0, 1), 0);
    thTrf01.set(thVec00, thRot01);
    thTrf12.set(thVec01, thRot12);

    // Apply Transformations // Matrix transformations
    // Index
    idxTrf.mul(idxTrfOffset);
    idxTrf.mul(idxTrf01);
    idxTrf.mul(idxTrf12);

    // Thumb
    thTrf.mul(thTrfOffset);
    thTrf.mul(thTrf01);
    thTrf.mul(thTrf12);
}

void HapticoKinesCeti::setForces(std::vector<FVector> forces, std::vector<FVector> torques)
{
    UE_LOG(LogTemp, Warning, TEXT("setForces function called"));
    UE_LOG(LogTemp, Log, TEXT("Force_values: %f %f %f"), forces[0].X, forces[0].Y, forces[0].Z);

    const float threshold = 1.0f;
    bool indexFingerActive = isFingerActive(forces, 0, threshold);
    bool thumbFingerActive = isFingerActive(forces, 1, threshold);

    // Logging the active state of the index and thumb fingers
    UE_LOG(LogTemp, Log, TEXT("IndexFingerActive: %s, ThumbFingerActive: %s"),
        indexFingerActive ? TEXT("true") : TEXT("false"),
        thumbFingerActive ? TEXT("true") : TEXT("false"));

    generateServoMotorsFeedback(indexFingerActive, thumbFingerActive, false, false);
}

bool HapticoKinesCeti::isFingerActive(const std::vector<FVector>& forces, int index, float threshold) {
    UE_LOG(LogTemp, Warning, TEXT("isFingerActive function called"));

    // Log the size of the forces vector, index, and threshold
    UE_LOG(LogTemp, Log, TEXT("Forces Vector Size: %d, Index: %d, Threshold: %f"), forces.size(), index, threshold);

    /////////////////////////////////newly added////////////////////////
    // Check if the index is within the size of the forces vector
    if (forces.size() > index) {
        FVector force = forces[index];
        // Log the force values at the specified index
        UE_LOG(LogTemp, Log, TEXT("Force at Index %d: X=%f, Y=%f, Z=%f"), index, force.X, force.Y, force.Z);

        // Return true if any component of the force exceeds the threshold
        return force.X > threshold || force.Y > threshold || force.Z > threshold;
    }
    else {
        // Log a warning if the index is out of bounds
        UE_LOG(LogTemp, Warning, TEXT("Index %d is out of bounds!"), index);
        return false;
    }
    ////////////////////////////////////////////////////////////////////////

    return forces.size() > index && (forces[index].X > threshold || forces[index].Y > threshold || forces[index].Z > threshold);
}

void HapticoKinesCeti::generateServoMotorsFeedback(bool data1, bool data2, bool data3, bool data4)
{
    UE_LOG(LogTemp, Warning, TEXT("generateServoMotorsFeedback function called"));

    // Log the boolean data values
    UE_LOG(LogTemp, Log, TEXT("Data1: %s, Data2: %s, Data3: %s, Data4: %s"),
        data1 ? TEXT("true") : TEXT("false"),
        data2 ? TEXT("true") : TEXT("false"),
        data3 ? TEXT("true") : TEXT("false"),
        data4 ? TEXT("true") : TEXT("false"));

    if (delay) {
        // Motor command to be sent to the exoskeleton over serial //
        char* charArray = new char[4];

        charArray[0] = '<';
        charArray[1] = (data1) ? '1' : '0';
        charArray[2] = (data2) ? '1' : '0';
        charArray[3] = '>';

        bool check = false;
        check = arduino.writeSerialPort(charArray, 5);    // Send the command to the haptic device

        if (!check) {
            //UE_LOG(LogTemp, Warning, TEXT("Arduino is not connected!"));
            UE_LOG(LogTemp, Warning, TEXT("Failed to send data to Arduino!"));
        }
        else {
            UE_LOG(LogTemp, Log, TEXT("Data sent to Arduino successfully: %s"), ANSI_TO_TCHAR(charArray));
        }

        delete[] charArray;     // Clean up the memory
        delay = false;
    }
    else {
        delay = true;
    }
}

int HapticoKinesCeti::getNumberOfDevices()
{
    //UE_LOG(LogTemp, Warning, TEXT("getNumberofDevices function called"));

    //return (*leapDevice)->getNumDevices();
    if (arduino.isConnected()) {
        std::cout << "Arduino is connected" << std::endl;
        //tool->start();
        UE_LOG(LogTemp, Log, TEXT("Arduino is connected!"));
        return (*leapDevice)->getNumDevices();
    }
    else {
        std::cout << "Arduino is not connected" << std::endl;
        UE_LOG(LogTemp, Warning, TEXT("Arduino is not connected!"));
        return 0;
    }
}












//void HapticoKinesCeti::readSensorData() {
//    UE_LOG(LogTemp, Warning, TEXT("readSensorData function called"));
//
//    // Receiving message by serial port //
//    char valchar[256];
//    int result = 0;
//    result = arduino.readSerialPort(valchar, 256);
//
//    // Log the result code
//    UE_LOG(LogTemp, Log, TEXT("Result code from readSerialPort: %d"), result);
//
//    // If no data was received, set default values
//    if (result == 0) {
//        // Log the error and set the result to the default error code
//        UE_LOG(LogTemp, Error, TEXT("Failed to read data from serial port. Using default values."));
//        result = 184;
//
//        // Set a safe default data string that matches the expected format
//        strcpy(valchar, "1,1,0.10,-0.68,0.78,0.01,0.02\n"
//                        "1,1,0.11,-0.69,0.79,0.02,0.03\n"
//                        "1,1,0.12,-0.70,0.80,0.03,0.04\n"
//                        "1,1,0.13,-0.71,0.81,0.04,0.05\n"
//                        "1,1,0.14,-0.72,0.82,0.05,0.06\n"
//                        "1,1,0.15,-0.73,0.83,0.06,0.07");
//
//        // Log the default data being used
//        UE_LOG(LogTemp, Log, TEXT("Using default data: %s"), *FString(valchar));
//    }
//    else {
//        // If data was successfully read, log the received data
//        UE_LOG(LogTemp, Log, TEXT("Received data: %s"), *FString(valchar));
//    }
//
//    // Ensure we are not working with corrupted data
//    if (strlen(valchar) > 0 && strlen(valchar) < 256) {
//        parseSerialData(valchar);
//    }
//    else {
//        UE_LOG(LogTemp, Error, TEXT("Received malformed or empty data. Skipping parse."));
//    }
//
//    // Call the parse function to process the data
//    // parseSerialData(valchar);
//
//    //if (result != 0) parseSerialData(valchar);
//}


//void HapticoKinesCeti::parseSerialData(const char* valchar) {
//    UE_LOG(LogTemp, Warning, TEXT("parseSerialData function called"));
//
//    int commaIdx[8] = { 0 };  // array to store the indices of commas in valchar
//    std::string strValues[7];  // array of strings to store the separated values
//    int idx = 0;  // index used to track the number of parsed values.
//
//    try {  // When a comma is found, its index is stored in commaIdx, and idx is incremented. The loop stops if idx reaches 7.
//        for (int h = 0; h < strlen(valchar); h++) {
//            if (valchar[h] == ',') {
//                commaIdx[idx++] = h;
//                if (idx >= 7) break;
//            }
//            else if (idx < 7) {
//                strValues[idx] += valchar[h];
//            }
//        }
//
//        if (idx < 6) {
//            throw std::invalid_argument("Insufficient comma-separated values");
//        }
//
//        // Converts each string in strValues to a double and stores it in the values array.
//        double values[7];
//        for (int i = 0; i < 7; ++i) {
//            values[i] = std::stod(strValues[i]);
//        }
//
//        motorStatus1 = (values[0] == 1) ? true : false;    // Index flex
//        motorStatus2 = (values[1] == 1) ? true : false;    // Thumb flex
//        rawFingerData[0] = values[2];
//        rawFingerData[1] = values[3];
//        accX = values[4];
//        accY = values[5];
//        accZ = values[6];
//
//        UE_LOG(LogTemp, Log, TEXT("Parsed data: %f, %f, %f, %f, %f, %f, %f"),
//            values[0], values[1], values[2], values[3], values[4], values[5], values[6]);
//
//        // Debugging output
//        UE_LOG(LogTemp, Log, TEXT("motorStatus1: %s, motorStatus2: %s, rawFingerData[0]: %f, rawFingerData[1]: %f, accX: %f, accY: %f, accZ: %f"),
//            motorStatus1 ? TEXT("true") : TEXT("false"),
//            motorStatus2 ? TEXT("true") : TEXT("false"),
//            rawFingerData[0],
//            rawFingerData[1],
//            accX,
//            accY,
//            accZ
//        );
//    }
//    catch (const std::exception& e) {
//        UE_LOG(LogTemp, Error, TEXT("Error parsing data: %s."), *FString(e.what()));
//    }
//}