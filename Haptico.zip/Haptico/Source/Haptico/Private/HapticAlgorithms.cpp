// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticAlgorithms.h"
#include "IHaptico.h"

HapticAlgorithms::HapticAlgorithms(IHaptico* hap)
{
	haptico = hap;
}

FVector HapticAlgorithms::pullToPoint(FVector position, FVector target, double maxForce, double k)
{
	FVector resultF = k * (target - position);
	if (resultF.Size() > maxForce)
	{
		resultF.Normalize();
		resultF *= maxForce;
	}
	return resultF;
}

bool HapticAlgorithms::isPlayerMoving()
{
	if (haptico->getLinearVelocity().Size() >= 0.07)
	{
		return true;
	}
	return false;
}