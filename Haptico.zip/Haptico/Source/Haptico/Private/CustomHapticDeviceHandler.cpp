#include "CustomHapticDeviceHandler.h"
#include "IHaptico.h"
#include "CVirtuoseDevice.h"
#include "HapticoChai.h"
#include "HapticoGlove.h"
#include "HapticoKinesCeti.h"

namespace CustomHapticHandler
{
	//==============================================================================
	/*!
	Constructor of cHapticDeviceHandler.
	*/
	//==============================================================================
	CustomHapticDeviceHandler::CustomHapticDeviceHandler()
		: m_numDevices(0)
		, m_nullHapticDevice(chai3d::cGenericHapticDevice::create())
		, m_devices{ chai3d::cGenericHapticDevicePtr() },
		nullDevice(MakeShared<HapticoDevice>())
	{
		hapticDevices.SetNum(C_MAX_HAPTIC_DEVICES);
		// search for available haptic devices
		//update();
	}

	//==============================================================================
	/*!
	Destructor of cHapticDeviceHandler.
	*/
	//==============================================================================
	CustomHapticDeviceHandler::~CustomHapticDeviceHandler()
	{
		// removed so that the phantom omni device doesnt crash at end
		/*
		// clear current list of devices
#pragma unroll C_MAX_HAPTIC_DEVICES
		for (unsigned int i = 0; i < C_MAX_HAPTIC_DEVICES; i++)
			m_devices[i] = chai3d::cGenericHapticDevicePtr();
		*/
	}

	//==============================================================================
	/*!
	This method searches and lists all haptic devices connected to the computer.
	*/
	//==============================================================================
	void CustomHapticDeviceHandler::update(SupportedDevices type)
	{
		// temp variables
		int count = 0;
		HapticoDevice hd;
		chai3d::cGenericHapticDevicePtr device;

		// clear current list of devices
		m_numDevices = 0;
		for (unsigned int i = 0; i < C_MAX_HAPTIC_DEVICES; i++)
		{
			m_devices[i] = nullptr;
			hapticDevices[i] = nullptr;			
		}

		//switch (type)
		//{
		//case SupportedDevices::Falcon:
		//	break;
		//case SupportedDevices::Glove:

		//	{
		//	TSharedPtr<HapticoGlove> d = MakeShared<HapticoGlove>();
		//	d->leapDevice = new cLeapDevicePtr();
		//	*(d->leapDevice) = chai3d::cLeapDevice::create(0);
		//	hapticDevices[0] = d;
		//	m_numDevices++;
		//	}
		//	break;
		//default:
		//	//TSharedPtr<HapticoDevice> e = MakeShared<HapticoDevice>();
		//	break;
		//}
		

		//--------------------------------------------------------------------------
		// search for Force Dimension devices
		//--------------------------------------------------------------------------
#if defined(C_ENABLE_DELTA_DEVICE_SUPPORT)

	// check for how many devices are available for this class of devices
		count = chai3d::cDeltaDevice::getNumDevices();

		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = chai3d::cDeltaDevice::create(i);
			//if (device->open()) {
				//m_devices[m_numDevices] = device;
				TSharedPtr<HapticoChai> d = MakeShared<HapticoChai>();
				d->hapticDevice = new cGenericHapticDevicePtr();
				//chai3d::cGenericHapticDevicePtr& a_hapticDevice = d->hapticDevice;
				*(d->hapticDevice) = device;
				hapticDevices[m_numDevices] = d;
				m_numDevices++;
				//device->close();
			//}
		}

#endif

		//--------------------------------------------------------------------------
		// search for Leap devices
		//--------------------------------------------------------------------------
#if defined(C_ENABLE_LEAP_DEVICE_SUPPORT)

	// check for how many devices are available for this class of devices
		count = chai3d::cLeapDevice::getNumDevices();
		UE_LOG(LogTemp, Log, TEXT("LeapDeviceCount: %d"), count);
		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = chai3d::cLeapDevice::create(i);
			//if (device->open()) {
			//m_devices[m_numDevices] = device;
			//m_numDevices++;

			TSharedPtr<HapticoKinesCeti> d = MakeShared<HapticoKinesCeti>();
			d->leapDevice = new cGenericHapticDevicePtr();
			*(d->leapDevice) = device;
			if (i == 0)
			{
				hapticDevices[0] = d;
			}
			m_numDevices++;
			//device->close();
		//}
		}

#endif

		//--------------------------------------------------------------------------
		// search for Sixense devices
		//--------------------------------------------------------------------------
#if defined(C_ENABLE_SIXENSE_DEVICE_SUPPORT)

	// check for how many devices are available for this class of devices
		count = chai3d::cSixenseDevice::getNumDevices();

		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = chai3d::cSixenseDevice::create(i);
			//if (device->open()) {
			m_devices[m_numDevices] = device;
			m_numDevices++;
			//device->close();
		//}
		}

#endif

		//--------------------------------------------------------------------------
		// search for 3D-Systems devices
		//--------------------------------------------------------------------------
#if defined(C_ENABLE_PHANTOM_DEVICE_SUPPORT)

	// check for how many devices are available for this class of devices
		count = chai3d::cPhantomDevice::getNumDevices();

		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = chai3d::cPhantomDevice::create(i);
			//if (device->open()) {
			m_devices[m_numDevices] = device;
			m_numDevices++;
			//device->close();
		//}
		}

#endif

		//--------------------------------------------------------------------------
		// search for MyCustom device
		//--------------------------------------------------------------------------
#if defined(C_ENABLE_CUSTOM_DEVICE_SUPPORT)

	// check for how many devices are available for this class of devices
		count = chai3d::cMyCustomDevice::getNumDevices();

		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = chai3d::cMyCustomDevice::create(i);
			//if (device->open()) {
			m_devices[m_numDevices] = device;
			m_numDevices++;
			//device->close();
		//}
		}

#endif

		// check for how many devices are available for this class of devices
		count = cVirtuoseDevice::getNumDevices();

		// open all remaining devices
		for (int i = 0; i < count; i++)
		{
			device = cVirtuoseDevice::create(i);
			//if (device->open()) {
			m_devices[m_numDevices] = device;
			m_numDevices++;
			//device->close();
		//}
		}
	}

	//==============================================================================
	/*!
	This method returns the specifications of the i'th device.

	\param  a_deviceSpecifications  Returned result
	\param  a_index                 Index number of the device.

	\return __true__ if operation succeeds, __false__ otherwise.
	*/
	//==============================================================================
	bool CustomHapticDeviceHandler::getDeviceSpecifications(chai3d::cHapticDeviceInfo& a_deviceSpecifications,
		unsigned int a_index)
	{
		if (a_index < m_numDevices)
		{
			a_deviceSpecifications = m_devices[a_index]->getSpecifications();
			return true;
		}
		else
		{
			return false;
		}
	}

	//==============================================================================
	/*!
	This method returns a handle to the i'th device if available.

	\param  a_hapticDevice  Handle to device
	\param  a_index         Index number of the device.

	\return __true__ if operation succeeds, __false__ otherwise.
	*/
	//==============================================================================
	bool CustomHapticDeviceHandler::getDevice(chai3d::cGenericHapticDevicePtr& a_hapticDevice,
		unsigned int a_index)
	{
		if (a_index < m_numDevices)
		{
			a_hapticDevice = m_devices[a_index];
			return true;
		}
		else
		{
			a_hapticDevice = m_nullHapticDevice;
			return false;
		}
	}
	bool CustomHapticDeviceHandler::getHapticoDevice(TSharedPtr<HapticoDevice>& hapticoDevice, unsigned int a_index)
	{
		if (a_index < m_numDevices) {
			hapticoDevice = hapticDevices[a_index];
			return true;
		}
		else {
			hapticoDevice = nullDevice;
			return false;
		}
		
	}
	bool CustomHapticDeviceHandler::findDeviceOfType(SupportedDevices InType)
	{
		
		int c = 0;
		switch (InType)
		{
		case SupportedDevices::Falcon:
			c = chai3d::cDeltaDevice::getNumDevices();
			break;
		case SupportedDevices::Glove:				
			c = chai3d::cLeapDevice::getNumDevices();
			break;
		case SupportedDevices::KinesCeti:
			c = chai3d::cLeapDevice::getNumDevices();
			break;
		default:
			break;
		}

		if (c > 0)
		{
			return true;
		}
		else {
			return false;
		}
		
	}
}