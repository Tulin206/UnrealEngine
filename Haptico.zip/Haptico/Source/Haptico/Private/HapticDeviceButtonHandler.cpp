// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticDeviceButtonHandler.h"
#include "IHaptico.h"

HapticDeviceButtonHandler::HapticDeviceButtonHandler(IHaptico* hap)
{
	haptico = hap;
}

/** Checks if the first button of the haptic device is clicked. This method only returns true once when the button is pressed until it is released again.
*/
bool HapticDeviceButtonHandler::button1Clicked()
{
	bool button1Pressed = haptico->isFirstButtonActivated();
	if (button1Pressed && !button1AlreadyPressed)
	{
		button1AlreadyPressed = true;
		return true;
	}
	else if (button1Pressed && button1AlreadyPressed)
	{
		return false;
	}
	else if (!button1Pressed && button1AlreadyPressed)
	{
		button1AlreadyPressed = false;
	}
	return false;
}

/** Checks if the second button of the haptic device is clicked. This method only returns true once when the button is pressed until it is released again.
*/
bool HapticDeviceButtonHandler::button2Clicked()
{
	bool button2Pressed = haptico->isSecondButtonActivated();
	if (button2Pressed && !button2AlreadyPressed)
	{
		button2AlreadyPressed = true;
		return true;
	}
	else if (button2Pressed && button2AlreadyPressed)
	{
		return false;
	}
	else if (!button2Pressed && button2AlreadyPressed)
	{
		button2AlreadyPressed = false;
	}
	return false;
}