// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticInput.h"
#include "IHaptico.h"

bool UHapticInput::ShouldThreadStop()
{
	return bStopThread;
}

void UHapticInput::StopThread()
{
	bStopThread = true;
}

void UHapticInput::ResetStopThread()
{
	bStopThread = false;
}

void UHapticInput::StoreForce(FVector InForce)
{
	Force = InForce;
}

FVector UHapticInput::GetStoredForce()
{
	return Force;
}

void UHapticInput::StoreForces(std::vector<FVector> InForces)
{
	Forces = InForces;
}

std::vector<FVector> UHapticInput::GetStoredForces()
{
	return Forces;
}

std::vector<FVector> UHapticInput::GetStoredTorques()
{
	return Torques;
}

void UHapticInput::StoreTorques(std::vector<FVector> InTorques)
{
	Torques = InTorques;
}

void UHapticInput::StoreTorque(FVector InTorque)
{
	Torque = InTorque;
}

FVector UHapticInput::GetStoredTorque()
{
	return Torque;
}

int UHapticInput::GetStoredID()
{
	return ID;
}

void UHapticInput::StoreID(int id)
{
	ID = id;
}
