// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "IHaptico.h"
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "GenericPlatform/GenericPlatform.h"
#include "GenericPlatform/GenericPlatformProcess.h"
#include "CustomHapticDeviceHandler.h"

THIRD_PARTY_INCLUDES_START
#include <chai3d.h>
#include <CPrecisionClock.h>
#include <HapticoDevice.h>
#include <HapticStructsAndEnums.h>
THIRD_PARTY_INCLUDES_END

DEFINE_LOG_CATEGORY(LogHaptico)

#define USE_VIRTUOSE

using namespace chai3d;

class FHaptico : public IHaptico
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	FVector getPosition();
	FMatrix getRotation();
	FVector getForce();
	FVector getTorque();
	FVector getLinearVelocity();
	FVector getAngularVelocity();
	bool isFirstButtonActivated();
	bool isSecondButtonActivated();
	bool connect();
	void disconnect();
	void measureTick(int32 numberOfTicks);
	double getDeltaTime();
	void setForce(FVector force);
	void setTorque(FVector torque);
	void ApplyForceAndTorque(FVector force, FVector torque);
	void startTheClock();
	void initMeasurementOfTicks();
	void initDeltaTime();
	void calibrate(bool forceCalibration);

	bool findDeviceOfType(SupportedDevices type);
	int getNumberOfContactPoints();

	std::vector<FVector> getPositions();
	std::vector<FMatrix> getRotations();
	void ApplyForces(std::vector<FVector> forces, std::vector<FVector> torques);
	void SetDeviceType(SupportedDevices type);

private:
	cPrecisionClock clock;
	cGenericHapticDevicePtr* hapticDevice;
	CustomHapticHandler::CustomHapticDeviceHandler* handler;
	int tickCount = 0;
	bool alreadyConnectedWithPhantom = false;
	double lastTickTime;
	double lastMeasureTime;

	TSharedPtr<HapticoDevice> hapticoDevice;
	int contactPoints = 1;
	SupportedDevices type;
};

IMPLEMENT_MODULE(FHaptico, Haptico)

void FHaptico::StartupModule()
{
}

void FHaptico::ShutdownModule()
{
}

#define VAR_NAME_HELPER(name) TEXT(#name)
#define VAR_NAME(x) VAR_NAME_HELPER(x)

#define CHECK_STATE_STR(x) case(x):return VAR_NAME(x);

const TCHAR* State2Str(const cHapticDeviceModel state)
{
	switch (state)
	{
		CHECK_STATE_STR(C_HAPTIC_DEVICE_VIRTUAL);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_DELTA_3);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_DELTA_6);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_OMEGA_3);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_OMEGA_6);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_OMEGA_7);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_SIGMA_6P);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_SIGMA_7);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_FALCON);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_XTH_1);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_XTH_2);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_MPR);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_KSD_1);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_VIC_1);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_TOUCH);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_OMNI);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_DESKTOP);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_15_6DOF);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_30_6DOF);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_PHANTOM_OTHER);
		CHECK_STATE_STR(C_TRACKER_DEVICE_SIXENSE);
		CHECK_STATE_STR(C_TRACKER_DEVICE_LEAP);
		CHECK_STATE_STR(C_HAPTIC_DEVICE_CUSTOM);
	default:
		return TEXT("Invalid");
	}
}

void logAllHapticDeviceInfo(CustomHapticHandler::CustomHapticDeviceHandler* handle)
{
	unsigned int numDevices = handle->getNumDevices();
	FString numDevicesS = FString::Printf(TEXT("Number of haptic devices found: %u"), numDevices);

	// Log each device
	for (unsigned int i = 0; i < numDevices; i++)
	{
		chai3d::cHapticDeviceInfo deviceSpecification;
		handle->getDeviceSpecifications(deviceSpecification, i);
		FString modelName(deviceSpecification.m_modelName.c_str());
		FString manufacturerName(deviceSpecification.m_manufacturerName.c_str());
		FString deviceInfoString = FString::Printf(TEXT("Haptic Device nr.: %u. Model: %s. Manufactur: %s. Enum: %s"), i,
			*modelName,
			*manufacturerName,
			State2Str(deviceSpecification.m_model));

		UE_LOG(LogHaptico, Log, TEXT("%s"), *deviceInfoString);
	}
}

/*
opens a connection to the haptic device to make it ready for communication
*/
bool FHaptico::connect()
{
	if (alreadyConnectedWithPhantom)
	{
		return true;
	}

	//hapticDevice = new cGenericHapticDevicePtr();
	hapticoDevice = MakeShared<HapticoDevice>();
	handler = new CustomHapticHandler::CustomHapticDeviceHandler();
	handler->update(type);


	//logAllHapticDeviceInfo(handler);

	if (handler->getHapticoDevice(hapticoDevice, 0))
	{
		//(*hapticDevice)->open();
		hapticoDevice->open();
		contactPoints = hapticoDevice->getContactPoints();

		// TODO this print is a bit redundant while logAllHapticDeviceInfo exists

		//FString modelName((*hapticDevice)->m_specifications.m_modelName.c_str());
		//FString manufacturerName((*hapticDevice)->m_specifications.m_manufacturerName.c_str());
		//FString deviceInfoString = FString::Printf(TEXT("Connected haptic device. Model: %s. Manufactur: %s. Enum: %s"),
		//	*modelName,
		//	*manufacturerName,
		//	State2Str((*hapticDevice)->m_specifications.m_model));

		//UE_LOG(LogHaptico, Log, TEXT("%s"), *deviceInfoString);

		// TODO
		//if ((*hapticDevice)->m_specifications.m_modelName == "PHANTOM Omni") {
		contactPoints = hapticoDevice->getContactPoints();
		alreadyConnectedWithPhantom = true;
		return true;
		//}
		//return false;
	}
	else
	{
		return false;
	}
}

/*
disconnects from the haptic device
*/
void FHaptico::disconnect()
{
	std::vector<FVector> resetVector = { FVector() };
	if (alreadyConnectedWithPhantom)
	{
		//(*hapticDevice)->setForce(cVector3d(0, 0, 0));
		hapticoDevice->setForces(resetVector, resetVector);
	}
	else
	{
		//(*hapticDevice)->setForce(cVector3d(0, 0, 0));
		//(*hapticDevice)->~cGenericHapticDevice();
		//(*hapticDevice).~shared_ptr();
		//delete hapticDevice;
		hapticoDevice->setForces(resetVector, resetVector);
		hapticoDevice->disconnect();
		hapticoDevice.Reset();
		delete handler;
	}
}

bool FHaptico::findDeviceOfType(SupportedDevices InType)
{
	handler = new CustomHapticHandler::CustomHapticDeviceHandler();
	bool foundADevice = handler->findDeviceOfType(InType);
	delete handler;
	return foundADevice;
}
int FHaptico::getNumberOfContactPoints()
{
	return contactPoints;
}
/**
	Counts how long it takes to make a numver of ticks.
*/
void FHaptico::measureTick(int32 numberOfTicks)
{
	tickCount++;
	if (tickCount >= numberOfTicks)
	{
		double current = clock.getCurrentTimeSeconds();
		double timeSpan = current - lastMeasureTime;
		double framerate = numberOfTicks / timeSpan;
		FString s = FString::Printf(
			TEXT("Measured %d Ticks. It took %f seconds\nThis means we have a FrameRate for the haptic loop of %f"),
			numberOfTicks,
			timeSpan,
			framerate
		);
		UE_LOG(LogTemp, Log, TEXT("%s"), *s);
		tickCount = 0;
		lastMeasureTime = current;
	}
}

double FHaptico::getDeltaTime()
{
	double currentTime = clock.getCurrentTimeSeconds();
	double delta = currentTime - lastTickTime;
	lastTickTime = currentTime;
	return delta;
}

/**
gets the current force of the haptic device
*/
FVector FHaptico::getForce()
{
	cVector3d force(0, 0, 0);
	(*hapticDevice)->getForce(force);
	return FVector(force.x(), force.y(), force.z());
}

/**
checks if the first button is activated
*/
bool FHaptico::isFirstButtonActivated()
{
	bool result = false;
	//(*hapticDevice)->getUserSwitch(0, result);
	return result;
}

/**
checks if the second button is activated
*/
bool FHaptico::isSecondButtonActivated()
{
	bool result = false;
	//(*hapticDevice)->getUserSwitch(1, result);
	return result;
}

/*
	gets the current linear velocity
*/
FVector FHaptico::getLinearVelocity()
{
	cVector3d chai_res(0, 0, 0);
	(*hapticDevice)->getLinearVelocity(chai_res);
	return FVector(chai_res.x(), chai_res.y(), chai_res.z());
}

/*
gets the current angular velocity
*/
FVector FHaptico::getAngularVelocity()
{
	cVector3d chai_res(0, 0, 0);
	(*hapticDevice)->getAngularVelocity(chai_res);
	return FVector(chai_res.x(), chai_res.y(), chai_res.z());
}

/**
	gets the current position of the haptic device
*/
FVector FHaptico::getPosition()
{
	cVector3d position(0, 0, 0);
	bool error = (*hapticDevice)->getPosition(position);
	return FVector(position.x(), position.y(), position.z());
}

/**
gets the current rotation of the haptic device as a 3x3 Matrix
*/
FMatrix FHaptico::getRotation()
{
	cMatrix3d rotation(0, 0, 0);
	(*hapticDevice)->getRotation(rotation);
	return FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
		FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
		FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
		FVector(0, 0, 0));
}



/**
	sends a force to the haptic device
*/
void FHaptico::setForce(FVector force)
{
	cVector3d cForce(force.X, force.Y, force.Z);
	(*hapticDevice)->setForce(cForce);
}

/**
sends a torque to the haptic device
*/
void FHaptico::setTorque(FVector torque)
{
	cVector3d cTorque(torque.X, torque.Y, torque.Z);
	cVector3d cForce(0, 0, 0);
	(*hapticDevice)->getForce(cForce);
}

void FHaptico::ApplyForceAndTorque(FVector force, FVector torque)
{
	cVector3d cTorque(torque.X, torque.Y, torque.Z);
	cVector3d cForce(force.X, force.Y, force.Z);
	(*hapticDevice)->setForceAndTorque(cForce, cTorque);
}

void FHaptico::startTheClock()
{
	clock.start();
}

/*
	Initializes the first time stamp for measuring the ticks
	and therefore the haptic framerate
*/
void FHaptico::initMeasurementOfTicks()
{
	lastMeasureTime = clock.getCurrentTimeSeconds();
}

void FHaptico::initDeltaTime()
{
	lastTickTime = clock.getCurrentTimeSeconds();
}

/**
gets the current torque of the haptic device
*/
FVector FHaptico::getTorque()
{
	cVector3d torque(0, 0, 0);
	(*hapticDevice)->getTorque(torque);
	return FVector(torque.x(), torque.y(), torque.z());
}

/* Calibrate */
void FHaptico::calibrate(bool forceCalibration)
{
	//(*hapticDevice)->calibrate(forceCalibration);
	hapticoDevice->calibrate(forceCalibration);
}

/*
* Methods for the HapticoDevice Class
*/
std::vector<FVector> FHaptico::getPositions()
{
	return hapticoDevice->getPositions();
}

std::vector<FMatrix> FHaptico::getRotations() {

	return hapticoDevice->getRotations();

}

void FHaptico::ApplyForces(std::vector<FVector> forces, std::vector<FVector> torques)
{
	hapticoDevice->setForces(forces, torques);
}

void FHaptico::SetDeviceType(SupportedDevices Intype)
{
	type = Intype;
}
