// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticsManager.h"
#include "Async/AsyncWork.h"
#include "HapticThread.h"
#include "HapticInput.h"
#include "HapticOutput.h"
#include "IHaptico.h"

// Sets default values
AHapticsManager::AHapticsManager()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	TicksToMeasure = 10000;
	bMeasureTheHapticTick = false;
	HapticThreadType = EHapticThreadType::Delegate;

	TranslationScale = 3000;
}

// Called when the game starts or when spawned
void AHapticsManager::BeginPlay()
{
	Super::BeginPlay();
	UHapticInput::getInst().ResetStopThread();	

	//StartHapticThread();
}

// Called when the actor is destroyed (at game end)
void  AHapticsManager::EndPlay(EEndPlayReason::Type type)
{
	UHapticInput::getInst().StopThread();
	FPlatformProcess::Sleep(0.1); //give the thread time to finish properly

	Super::EndPlay(type);
}

// Called every frame
void AHapticsManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AHapticsManager::StoreForce(FVector InForce)
{
	UHapticInput::getInst().StoreForce(InForce);
}

void AHapticsManager::StoreTorque(FVector InTorque)
{
	UHapticInput::getInst().StoreTorque(InTorque);
}

void AHapticsManager::StoreID(int ID)
{
	UHapticInput::getInst().StoreID(ID);
}

void AHapticsManager::StoreForces(std::vector<FVector> InForces, std::vector<FVector> InTorques)
{
	UHapticInput::getInst().StoreForces(InForces);
	UHapticInput::getInst().StoreTorques(InTorques);
}

FVector AHapticsManager::getHapticDevicePosition()
{
	return UHapticOutput::getInst().getHapticCursorPosition();
}

FVector AHapticsManager::getHapticDeviceLinearVelocity()
{
	return UHapticOutput::getInst().getHapticCursorLinearVelocity();
}

FVector AHapticsManager::getHapticDeviceAngularVelocity()
{
	return UHapticOutput::getInst().getHapticCursorAngularVelocity();
}

FMatrix AHapticsManager::getHapticDeviceRotation()
{
	return UHapticOutput::getInst().getHapticCursorRotation();
}

FRotator AHapticsManager::getHapticDeviceRotationAsUnrealRotator()
{
	FMatrix rotation = UHapticOutput::getInst().getHapticCursorRotation();

	return TranslateToUnrealRotator(rotation);
}

void AHapticsManager::ExecuteForceCalculation()
{
	// Start ForceCalculation
	OnCalculateForce.broadcast();

	StoreForces(ForcesOfNextTick, TorquesOfNextTick);

	//StoreForce(ForceOfNextTick);
	//StoreTorque(TorqueOfNextTick);
	//StoreID(componentID);
}

FVector AHapticsManager::TranslateBetweenUnrealAndHapticVector(const FVector pos)
{
	return FVector(-pos.X, pos.Y, pos.Z);
}

FRotator AHapticsManager::TranslateToUnrealRotator(const FMatrix rotation)
{
	FVector euler = rotation.Rotator().Euler();

	return FRotator(-euler.Y, -euler.Z, euler.X) + CalibratedDeviceOffset.GetRotation().Rotator();
}

FVector AHapticsManager::TranslateHapticLocationAndScaleToFVector(FVector pos, int32 scaling)
{
	FVector TranslatedDeviceLocation = (TranslateBetweenUnrealAndHapticVector(pos) * scaling);

	return TranslatedDeviceLocation + CalibratedDeviceOffset.GetTranslation();
}

void AHapticsManager::StartHapticThread()
{
	(new FAutoDeleteAsyncTask<FHapticThread>(IHaptico::Get(), this))->StartBackgroundTask();
}

void AHapticsManager::ResizeBuffers()
{
	ForcesOfNextTick.resize(numberOfContactPoints, FVector());
	TorquesOfNextTick.resize(numberOfContactPoints, FVector());
}
