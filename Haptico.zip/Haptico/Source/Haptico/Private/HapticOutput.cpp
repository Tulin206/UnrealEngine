// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticOutput.h"
#include "IHaptico.h"

UHapticOutput& UHapticOutput::getInst()
{
	static UHapticOutput instance;
	return instance;
}

UHapticOutput::UHapticOutput()
{
}

UHapticOutput::~UHapticOutput()
{
}

void UHapticOutput::StoreHapticCursorLocation(FVector position)
{
	hapticCursorPosition = position;
}

FVector UHapticOutput::getHapticCursorPosition()
{
	return hapticCursorPosition;
}

void UHapticOutput::StoreHapticCursorRotation(FMatrix rotation)
{
	hapticCursorRotation = rotation;
}

FMatrix UHapticOutput::getHapticCursorRotation()
{
	return hapticCursorRotation;
}

FVector UHapticOutput::getHapticCursorLinearVelocity()
{
	return hapticCursorLinearVelocity;
}

FVector UHapticOutput::getHapticCursorAngularVelocity()
{
	return hapticCursorAngularVelocity;
}

void UHapticOutput::StoreHapticCursorAngularVelocity(FVector angularVelocity)
{
	hapticCursorAngularVelocity = angularVelocity;
}

void UHapticOutput::StoreHapticCursorLinearVelocity(FVector linearVelocity)
{
	hapticCursorLinearVelocity = linearVelocity;
}

/// <summary>
/// Stores the haptic data (just sets for later use, does not apply directly)
/// </summary>
/// <param name="InData">The data.</param>
void UHapticOutput::StoreHapticData(FHapticData InData)
{
	HapticData = InData;
}

/// <summary>
/// Gets the haptic data.
/// </summary>
/// <returns>FHapticData Object</returns>
FHapticData UHapticOutput::getHapticData()
{
	return HapticData;
}