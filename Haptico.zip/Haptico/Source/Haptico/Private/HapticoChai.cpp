#include "HapticoChai.h"

HapticoChai::HapticoChai()
{

}

HapticoChai::~HapticoChai()
{

}

bool HapticoChai::open()
{
	return (*hapticDevice)->open();
}

bool HapticoChai::close()
{
	return false;
}

void HapticoChai::disconnect()
{
	(*hapticDevice)->~cGenericHapticDevice();
	(*hapticDevice).~shared_ptr();
	delete hapticDevice;
}

bool HapticoChai::calibrate(bool calibrated) {
	return (*hapticDevice)->calibrate(calibrated);
}

std::vector<FVector> HapticoChai::getPositions()
{
	std::vector<FVector> result = {};
	cVector3d position(0, 0, 0);
	(*hapticDevice)->getPosition(position);
	result.push_back(FVector(position.x(), position.y(), position.z()));
	return result;
}

void HapticoChai::setForces(std::vector<FVector> forces, std::vector<FVector> torques)
{
	cVector3d cForce(forces[0].X, forces[0].Y, forces[0].Z);
	cVector3d cTorque(torques[0].X, torques[0].Y, torques[0].Z);
	(*hapticDevice)->setForceAndTorque(cForce, cTorque);	
}

int HapticoChai::getNumberOfDevices()
{
	return (*hapticDevice)->getNumDevices();
}

