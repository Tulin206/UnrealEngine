// Fill out your copyright notice in the Description page of Project Settings.


#include "HapticoDevice.h"

HapticoDevice::HapticoDevice()
{
	numberContactPoints = 1;
}

HapticoDevice::HapticoDevice(unsigned int n) : numberContactPoints(n)
{
}

HapticoDevice::~HapticoDevice()
{
}

bool HapticoDevice::open()
{
	return false;
}

bool HapticoDevice::close()
{
	return false;
}

std::vector<FVector> HapticoDevice::getPositions()
{
	return std::vector<FVector>();
}

std::vector<FMatrix> HapticoDevice::getRotations()
{
	return std::vector<FMatrix>();
}

int HapticoDevice::getNumberOfDevices()
{
	return 0;
}
