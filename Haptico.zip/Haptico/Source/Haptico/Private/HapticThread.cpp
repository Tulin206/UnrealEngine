// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#include "HapticThread.h"
#include "CoreMinimal.h"
#include "HapticsManager.h"
#include "Async/Async.h"
#include "HapticOutput.h"
#include "HapticInput.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/FileHelper.h"
#include "IHaptico.h"

void FHapticThread::DoWork()
{
	TArray<FString>SimData;
	TArray<FName>SimDataRowNames;
	int32 SimulationStep = 0;

	HapticDeviceButtonHandler buttonHandler(&haptico);
	bool connected = haptico.connect();

	if (connected || HapticsManager->bSimulation)
	{
		LoopCtr = 1;

		if (connected)
		{
			haptico.calibrate(false);
			// Inform others via delegate
			HapticsManager->OnAfterCalibratingDevice.ExecuteIfBound();
			HapticsManager->DeviceIsCalibrated = true;
			HapticsManager->numberOfContactPoints = haptico.getNumberOfContactPoints();
			HapticsManager->ResizeBuffers();
			

			FHapticData CurrentDeviceData = ReadDeviceData();
			// Get Device Offset
			HapticsManager->CalibratedDeviceOffset.SetTranslation(-CurrentDeviceData.location + HapticsManager->AdditionalDeviceOffset.GetTranslation());
			HapticsManager->CalibratedDeviceOffset.SetRotation(CurrentDeviceData.rotation.ToQuat() + HapticsManager->AdditionalDeviceOffset.GetRotation());
			// broadcast
			HapticsManager->OnAfterFirstHapticDataGathering.broadcast(CurrentDeviceData);

			haptico.startTheClock();

			if (HapticsManager->bMeasureTheHapticTick)
			{
				haptico.initMeasurementOfTicks();
			}

			haptico.initDeltaTime();
		}
		else if (HapticsManager->bSimulation)
		{
			// check if simulation CurrentDeviceData file exists and load the CurrentDeviceData
			if (!HapticsManager->SimulationDataTable)
			{
				UE_LOG(LogHaptico, Warning, TEXT("No Simulation DataTable pasted."));
			}
			else
			{
				SimDataRowNames = HapticsManager->SimulationDataTable->GetRowNames();

				SimulationStep = 1;
			}
		}

		FMatrix TempMatrix = FMatrix();
		FName RowName;
		FSimDataCSV* Row;

		/* -----------------------------------------------------------------------------------------------------------*/
		/*                                                     Main Loop                                              */
		/* -----------------------------------------------------------------------------------------------------------*/

		HapticsManager->OnBeforeStartHapticLoop.ExecuteIfBound();

		if (!HapticsManager->bSimulation
			|| (HapticsManager->bSimulation && (SimDataRowNames.Num() > 1)))
		{
			while (!UHapticInput::getInst().ShouldThreadStop())
			{
				if (HapticsManager->bMeasureTheHapticTick)
				{
					haptico.measureTick(HapticsManager->TicksToMeasure);
				}

				/*---------------------------------------*/
				// 1. Read device / simulation data
				/*---------------------------------------*/

				FHapticData CurrentDeviceData;

				if (!HapticsManager->bSimulation)
				{
					// Get Information from Device
					CurrentDeviceData = ReadDeviceData();
				}
				else
				{
#pragma region Simulation
					// Read Information from file
					if (SimulationStep >= SimDataRowNames.Num())
					{
						FGenericPlatformMisc::RequestExit(false); // a little bit drastic
						break;
					}

					// Read Device Data from Simulation DataTable
					{
						RowName = SimDataRowNames[SimulationStep];
						Row = HapticsManager->SimulationDataTable->FindRow<FSimDataCSV>(RowName, TEXT(""));
						if (!Row)
						{
							UE_DEBUG_BREAK();
						}

						CurrentDeviceData.location.X = Row->locationX;
						CurrentDeviceData.location.Y = Row->locationY;
						CurrentDeviceData.location.Z = Row->locationZ;

						TempMatrix.M[0][0] = Row->M00;
						TempMatrix.M[0][1] = Row->M01;
						TempMatrix.M[0][2] = Row->M02;
						TempMatrix.M[0][3] = Row->M03;
						TempMatrix.M[1][0] = Row->M10;
						TempMatrix.M[1][1] = Row->M11;
						TempMatrix.M[1][2] = Row->M12;
						TempMatrix.M[1][3] = Row->M13;
						TempMatrix.M[2][0] = Row->M20;
						TempMatrix.M[2][1] = Row->M21;
						TempMatrix.M[2][2] = Row->M22;
						TempMatrix.M[2][3] = Row->M23;
						TempMatrix.M[3][0] = Row->M30;
						TempMatrix.M[3][1] = Row->M31;
						TempMatrix.M[3][2] = Row->M32;
						TempMatrix.M[3][3] = Row->M33;
						CurrentDeviceData.rotation = TempMatrix;

						CurrentDeviceData.linearVelocity.X = Row->linearVelocityX;
						CurrentDeviceData.linearVelocity.Y = Row->linearVelocityY;
						CurrentDeviceData.linearVelocity.Z = Row->linearVelocityZ;

						CurrentDeviceData.angularVelocity.X = Row->angularVelocityX;
						CurrentDeviceData.angularVelocity.Y = Row->angularVelocityY;
						CurrentDeviceData.angularVelocity.Z = Row->angularVelocityZ;

						CurrentDeviceData.DeltaTime = Row->deltaTime;
					}
#pragma endregion Simulation
				}

				CurrentDeviceData.loopCtr = LoopCtr;

				// Buttons
				{
					HandleButtonClick(&buttonHandler, CurrentDeviceData.location, CurrentDeviceData.rotation);

					if (HapticsManager->HapticThreadType == EHapticThreadType::SetHapticData ||
						HapticsManager->HapticThreadType == EHapticThreadType::DelegateAndProvideData)
					{
						SetHapticData(CurrentDeviceData);
					}
					else if (HapticsManager->HapticThreadType == EHapticThreadType::Delegate ||
						HapticsManager->HapticThreadType == EHapticThreadType::DelegateAndProvideData)
					{
						HapticsManager->OnAfterGatheringHapticData.broadcast(CurrentDeviceData);
					}
				}

				/*---------------------------------------*/
				// 2. Calculate Forces
				/*---------------------------------------*/

				HapticsManager->ExecuteForceCalculation();

				/*---------------------------------------*/
				// 3. Set new Device Force and Torque
				/*---------------------------------------*/

				ApplyForceAndTorque();

				LoopCtr++;
				SimulationStep++;

				// Write Data to DeviceDataset
				HapticsManager->CurrentDeviceData = CurrentDeviceData;
			}
		}

		UE_LOG(LogHaptico, Log, TEXT("Haptics Thread ended. %d"), LoopCtr);

		haptico.disconnect();

#if WITH_EDITOR
		// necessary to keep the input thread alive when working in the editor
		UHapticInput::getInst().ResetStopThread();
#endif WITH_EDITOR
	}
	else
	{
		UE_LOG(LogHaptico, Warning, TEXT("No haptic device connected AND no simulation data provided!"));
	}




	//while (!UHapticInput::getInst().ShouldThreadStop()) {
	//	FHapticData CurrentDeviceData;
	//	CurrentDeviceData = ReadDeviceData();

	//	UE_LOG(LogTemp, Warning, TEXT("TEST"));

	//	HapticsManager->OnAfterGatheringHapticData.broadcast(CurrentDeviceData);

	//	HapticsManager->ExecuteForceCalculation();
	//	ApplyForceAndTorque();

	//	LoopCtr++;
	//}
	
	

	


}

void FHapticThread::SetHapticData(FVector InLocation, FMatrix InRotation, FVector InAngularVelocity, FVector InLinearVelocity)
{
	UHapticOutput::getInst().StoreHapticCursorLocation(InLocation);
	UHapticOutput::getInst().StoreHapticCursorRotation(InRotation);
	UHapticOutput::getInst().StoreHapticCursorAngularVelocity(InAngularVelocity);
	UHapticOutput::getInst().StoreHapticCursorLinearVelocity(InLinearVelocity);
}

/// <summary>
/// Sets the haptic data (just sets for later use, does not apply directly)
/// </summary>
/// <param name="InData">The data.</param>
void FHapticThread::SetHapticData(FHapticData InData)
{
	UHapticOutput::getInst().StoreHapticData(InData);
}

void FHapticThread::HandleButtonClick(HapticDeviceButtonHandler* InButtonHandler, FVector InLocation, FMatrix InRotation)
{
	AHapticsManager* hapticManagerPointer = HapticsManager; //necessary because the AsyncTask for buttonhandling needs this pointer
	bool button1clicked = InButtonHandler->button1Clicked();
	bool button2clicked = InButtonHandler->button2Clicked();

	AsyncTask(ENamedThreads::GameThread, [hapticManagerPointer, button1clicked, button2clicked, InLocation, InRotation]()
		{
			if (button1clicked)
			{
				hapticManagerPointer->button1Clicked();
				hapticManagerPointer->OnButton1Clicked.ExecuteIfBound();
			}
			else if (button2clicked)
			{
				hapticManagerPointer->button2Clicked();
				hapticManagerPointer->OnButton2Clicked.ExecuteIfBound();
			}
		});
}

/// <summary>
/// Applies the force and torque directly in this tick to the connected haptic device.
/// </summary>
void FHapticThread::ApplyForceAndTorque()
{
	// Previously: Set Default to very small force, cause the device does not like a 0 force
	std::vector<FVector> forces = { FVector(0,0,0) };
	std::vector<FVector> torques = { FVector(0,0,0) };

	if (!HapticsManager->bSimulation)
	{
		forces = UHapticInput::getInst().GetStoredForces();
		torques = UHapticInput::getInst().GetStoredTorques();
	}

	haptico.ApplyForces(forces, torques);
}

FHapticData FHapticThread::ReadDeviceData()
{
	FHapticData CurrentDeviceData;

	// Get Information from Device
	//CurrentDeviceData.location = haptico.getPosition();
	//CurrentDeviceData.rotation = haptico.getRotation();
	//CurrentDeviceData.linearVelocity = haptico.getLinearVelocity();
	//CurrentDeviceData.angularVelocity = haptico.getAngularVelocity();
	CurrentDeviceData.DeltaTime = haptico.getDeltaTime();
	CurrentDeviceData.locations = haptico.getPositions();
	CurrentDeviceData.rotations = haptico.getRotations();

	return CurrentDeviceData;
}