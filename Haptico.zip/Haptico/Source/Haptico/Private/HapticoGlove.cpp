#include "HapticoGlove.h"

#include "SerialPort.h"
#include "Leap.h"



HapticoGlove::HapticoGlove()
{
	
	//arduino = SerialPort(port);

	//handler = new cHapticDeviceHandler();

	//handler->getDevice(hapticDevice, 0);

	//world = new cWorld();

	//tool = new cToolCursor(world);

	//tool->setHapticDevice(hapticDevice);

	//LeapCreateConnection(NULL, &connection);
	//if (LeapOpenConnection(connection))
	//{
	//	isConnected = true;
	//};


}

HapticoGlove::~HapticoGlove()
{

}

bool HapticoGlove::open()
{
	return (*leapDevice)->open();

	if (arduino.isConnected()) {
		std::cout << "Arduino is connected" << std::endl;
		
		return (*leapDevice)->open();
	}
	else {
		std::cout << "Arduino is not connected" << std::endl;
		return false;
	}


}

bool HapticoGlove::close()
{
	//return false;
	if (arduino.isConnected()) {
		// Implement any cleanup code here if needed
		std::cout << "Arduino connection closed" << std::endl;
		// Explicitly close the serial port connection
		arduino.~SerialPort();
		return true;
	}
	else {
		//std::cout << "Arduino was not connected" << std::endl;
		return true;
	}
}

void HapticoGlove::disconnect()
{
	(*leapDevice)->~cGenericHapticDevice();
	(*leapDevice).~shared_ptr();
	delete leapDevice;
	if (arduino.isConnected()) {
		// Explicitly close the serial port connection
		arduino.~SerialPort();
	}
}

bool HapticoGlove::calibrate(bool calibrated)
{
	return (*leapDevice)->calibrate(calibrated);
}

std::vector<FVector> HapticoGlove::getPositions()
{
	//Leap::
	std::vector<FVector> result = {};
	cVector3d position(0, 0, 0);
	(*leapDevice)->getPosition(position);
	result.push_back(FVector(position.x(), position.y(), position.z()));
	/*result.push_back(FVector(position.x(), position.y(), position.z()));
	result.push_back(FVector(position.x(), position.y(), position.z()));*/


	

	
	//LeapPollConnection(connection, timeout_ms, &msg);
	//if (msg.type == eLeapEventType_Tracking && latest_tracking_event->nHands > 0)
	//{
	//	LEAP_VECTOR palm_position = latest_tracking_event->pHands[0].palm.position;
	//	LEAP_VECTOR thumb_tip_position = latest_tracking_event->pHands[0].palm.position;
	//}
	

	return result;
}

std::vector<FMatrix> HapticoGlove::getRotations()
{
	std::vector<FMatrix> result = {};
	cMatrix3d rotation(0, 0, 0);
	(*leapDevice)->getRotation(rotation);
	result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
		FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
		FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
		FVector(0, 0, 0)));	
	result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
		FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
		FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
		FVector(0, 0, 0)));	
	result.push_back(FMatrix(FVector(rotation.getCol0().x(), rotation.getCol0().y(), rotation.getCol0().z()),
		FVector(rotation.getCol1().x(), rotation.getCol1().y(), rotation.getCol1().z()),
		FVector(rotation.getCol2().x(), rotation.getCol2().y(), rotation.getCol2().z()),
		FVector(0, 0, 0)));

	return result;
}

void HapticoGlove::setForces(std::vector<FVector> forces, std::vector<FVector> torques)
{
	std::string vibratePattern = "";

	for (int i = 0; i < 3; i++)
	{
		if (forces[i].X > 1 || forces[i].Y > 1 || forces[i].Z > 1)
		{
			vibratePattern.append("1 ");	
		}
		else {
			vibratePattern.append("0 ");
		}
	}
	vibratePattern.pop_back();
	vibrate(vibratePattern);
	//vibrate("1 1 1");
	//UE_LOG(LogTemp, Warning, TEXT("Forces: %f %f %f"), forces[0].X, forces[0].Y, forces[0].Z);

	
}

int HapticoGlove::getNumberOfDevices()
{
	return (*leapDevice)->getNumDevices();
	if (arduino.isConnected()) {
		std::cout << "Arduino is connected" << std::endl;
		//tool->start();
		return (*leapDevice)->getNumDevices();
	}
	else {
		std::cout << "Arduino is not connected" << std::endl;
		return 0;
	}
	//return 1;
}

int HapticoGlove::getContactPoints()
{
	return 3;
}

void HapticoGlove::updateHaptics(void)
{
}

void HapticoGlove::updateVibrations(void)
{
}

// ------------------------ - modified------------------------------------------
// 
// Define a constant for the delay between sending data to Arduino
const int DELAY_BETWEEN_TRANSMISSIONS = 250;

void HapticoGlove::vibrate(const std::string& data)
{
	if (arduino.isConnected()) {
		std::cout << "Arduino is connected " << std::endl;
		std::cout << "Sending data to Arduino: " << data << std::endl;

		// Convert string to char array
		char* charArray = new char[data.size() + 2];
		std::copy(data.begin(), data.end(), charArray);
		charArray[data.size()] = '\n'; // Null-terminate the char array
		charArray[data.size() + 1] = '\0';
		std::cout << "charArray: " << charArray << std::endl;
		// std::cout << charArray << std::endl;

		// Send data to Arduino
		arduino.writeSerialPort(charArray, data.size() + 1);
		std::cout << "Hello World" << std::endl;

		// Clean up memory
		delete[] charArray;
		Sleep(10);

		// Add a delay between transmissions to prevent excessive buffering
		//std::this_thread::sleep_for(std::chrono::milliseconds(DELAY_BETWEEN_TRANSMISSIONS));
	}
	else {
		std::cout << "Arduino is not connected " << std::endl;
	}
}

//void HapticoGlove::vibrate(const std::string& data)
//{
//
//	if (arduino.isConnected()) {  // Use the open method to check connection status
//		//if (arduino.isConnected()) {
//		std::cout << "Arduino is connected " << std::endl;
//		std::cout << "Sending data to Arduino: " << data << std::endl;
//
//		// Convert string to char array
//		char* charArray = new char[data.size() + 1];
//		std::copy(data.begin(), data.end(), charArray);
//		charArray[data.size()] = '\0'; // Null-terminate the char array
//
//		// Send data to Arduino
//		arduino.writeSerialPort(charArray, data.size());
//
//		// Clean up memory
//		delete[] charArray;
//
//		// Add a delay between transmissions to prevent excessive buffering
//	
//		//std::this_thread::sleep_for(std::chrono::milliseconds(DELAY_BETWEEN_TRANSMISSIONS));
//		Sleep(10);
//	}
//	else {
//		std::cout << "Arduino is not connected " << std::endl;
//	}
//}

void HapticoGlove::vibrate(const int vibrationPattern[3])
{
	// Vibration pattern code here
	std::ostringstream oss;
	oss << vibrationPattern[0] << " " << vibrationPattern[1] << " " << vibrationPattern[2];
	vibrate(oss.str());
}


