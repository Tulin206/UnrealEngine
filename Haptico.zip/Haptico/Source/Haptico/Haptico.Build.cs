// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

using System.IO;
using System;
using UnrealBuildTool;

public class Haptico : ModuleRules
{
    public Haptico(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
        
        PublicDefinitions.Add("_CRT_SECURE_NO_WARNINGS");  // Supress Error Message "C4996 'sscanf': This function or variable may be unsafe. Consider using sscanf_s instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details." and other security warnings

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "InputCore",
            "HAP",
            "CollDetLibrary"
        });
        PrivateDependencyModuleNames.AddRange(new string[] { "Core" });
    }
}