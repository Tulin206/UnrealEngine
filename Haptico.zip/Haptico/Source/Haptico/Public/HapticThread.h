// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once
#include "Async/AsyncWork.h"
#include "HapticDeviceButtonHandler.h"
#include "HapticStructsAndEnums.h"
#include "IHaptico.h"

class AHapticsManager;

/*
	This class is the task that performs the haptic loop
	It gets information of the device and provides the data
	Providing Data works either as Delegation or storing
	Storing is triggered by the EHapticThreadType keyword SetHapticData
*/
class HAPTICO_API FHapticThread : public FNonAbandonableTask
{
	friend class FAutoDeleteAsyncTask<FHapticThread>;

public:

	FHapticThread(IHaptico& hapticoModule, AHapticsManager* hManager) :
		haptico(hapticoModule),
		HapticsManager(hManager)
	{
	}

protected:
	IHaptico& haptico;
	AHapticsManager* HapticsManager;

	/* This is were the work is done! The Haptic Loop */
	void DoWork();

	/*  Stores the data of the Haptic Loop for later requests */
	void SetHapticData(FHapticData data);

	void SetHapticData(FVector location, FMatrix rotation, FVector angularVelocity, FVector linearVelocity);

	/*  Handles button clicks within the haptic loop */
	void HandleButtonClick(HapticDeviceButtonHandler* buttonHandler, FVector location, FMatrix rotation);

	void ApplyForceAndTorque();

	FHapticData ReadDeviceData();

	FORCEINLINE TStatId GetStatId() const
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FHapticThread, STATGROUP_ThreadPoolAsyncTasks);
	}

private:

	uint64 LoopCtr;
};
