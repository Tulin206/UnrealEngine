#pragma once

#include "CoreMinimal.h"
#include "HapticoDevice.h"
#include "chai3d.h"
#include "SerialPort.h"


using namespace chai3d;

//const char* port = "\\\\.\\COM5";
//
//char output[255];
//char incoming[255];
//
//SerialPort arduino(port);

class HapticoKinesCeti : public HapticoDevice
{
public:
    HapticoKinesCeti();

    ~HapticoKinesCeti();

public:
    cGenericHapticDevicePtr* leapDevice;

    virtual bool open();

    virtual bool close();

    virtual void disconnect();

    virtual bool calibrate(bool calibrate);;

    virtual std::vector<FVector> getPositions();

    virtual std::vector<FMatrix> getRotations();

    virtual int getContactPoints() { return numberContactPoints; };
    //int getNumberOfDevices();

    virtual void setForces(std::vector<FVector> forces, std::vector<FVector> torques);

    virtual int getNumberOfDevices();

private:
    unsigned int numberContactPoints = 3;
    void generateServoMotorsFeedback(bool data1, bool data2, bool data3 = false, bool data4 = false);
    double fingerMeasurement(int FingerID);
    void updateCounter(int FingerID, double DCal);
    void updateMinMaxValues(int d);

    void readSensorData();
    void initializeFingerVectors();
    void applyHandTransformations();
    void readLeapDevice();
    void calculateFingerTransforms();
    /*void setFingerRotations();
    void setFingerMatrices();
    void applyTransformations();*/
    void parseSerialData(const char* valchar);
    bool isFingerActive(const std::vector<FVector>& forces, int index, float threshold);

    cVector3d position;
    cMatrix3d rotation;
    cVector3d handPosition;

    cVector3d positionSp, positionPipe;

    cMatrix3d ones;

    cVector3d indexPos;
    cVector3d indexPos2;
    cTransform rot0Index;
    cTransform transIndex;
    cTransform transIndex2;
    cVector3d thumbPos;
    cTransform rot0thumb;
    cTransform transthumb;

    cMatrix3d indexOffsetAngle;

    // Data we extract from Leapmotion's tool
    cVector3d idxVec00, idxVec01, idxVec12, idxVec23, idxVec34;
    cMatrix3d idxRotOffset, idxRot00, idxRot01, idxRot12, idxRot23, idxRot34;
    cTransform idxTrfOffset, idxTrf, idxTrf01, idxTrf12, idxTrf23, idxTrf34, hand;

    double idxangle[2] = { 0,0 }, thangle[2] = { 0,0 };
    //double rawFingerData[4] = { 0,0,0,0 }, prerawFingerData[4] = { 0,0,0,0 };
    double scale = 3;
    double idxd1 = scale * 0.03, idxL1 = scale * 0.03, idxL2 = scale * 0.05, idxL3 = scale * 0.04, idxL4 = scale * 0.02;

    cVector3d thVec00, thVec01, thVec12, thVec23, thVec34;
    cMatrix3d thRotOffset, thRotOffset2, thRot00, thRot002, thRot01, thRot12, thRot23, thRot34;
    cTransform thTrfOffset, thTrfOffset2, thTrf, thTrf002, thTrf01, thTrf12, thTrf23, thTrf34;
    double thd1 = scale * 0.03, thL1 = scale * 0.03, thH1 = scale * 0.03, thL2 = scale * 0.05, thL3 = scale * 0.04, thL4 = scale * 0.03;
    double indexMeas = 0, thumbMeas = 0, thumbMeas2 = 0, thumbMeas3 = 0;

    bool delay = true;

    double feedPos[4] = { 0,0,0,0 };
    bool coupled = false;

    // Booleans
    int expCond = 0; // Programming situation, 0 is starting point, no feedback; 2 is hand is closed, so  we start moving; 3 is hand is released, so the object should fall. Then maybe 4 to send a message somewhere, and then 0 again
    int fbCond = 0; // 0 quiet; 1 feedback is enabled
    int prevfbCond = 0;

    bool motorCommand1 = false, motorCommand2 = false, motorCommand3 = false, motorCommand4 = false;// Feedback command for the motors in the exoskeleton, 1-> Index flex, 2->Thumb flex, 3-> Thumb 

    bool motorStatus1 = false, motorStatus2 = false, motorStatus3 = false, motorStatus4 = false; // State of motors according to the exoskeleton

    double pre_val0 = 0, pre_val1 = 0, pre_val2 = 0, pre_val3 = 0, pre_val4 = 0, pre_val5 = 0, pre_val6 = 0, pre_val7 = 0;
    cMatrix3d pipeOrientation;

    cVector3d finger1, finger2;
    double boxX = 0, boxY = 0, boxZ = 0;
    //double cylRin, cylRout, cylH;

    bool pickLogic = false;

    double savedFBPositions[4] = { 0,0,0,0 };   // When applying feedback, we save those positions in order to apply them to the simulation, instead of checking and applying the positions of the exo

    int stimIDTotal = 8; // from 0 until the maximum length of stimuli
    bool goalReached = false;

    // Object that we get the interaction with
    cGenericObject* pickedObject;
    //cODEGenericBody* pickedODEobject;

    double counter[4];
    double Ucounter[4];
    double maxVal[4];
    double minVal[4];
    double calVal;
    double DCal;
    double d1cal;
    double d2cal;

    int showData;

    double rawFingerData[4];
    double prerawFingerData[4];
    int nSensors = 2;

    bool isVibrate;
    bool wasVibrate;
    bool handRelease;
    bool prevhandRelease;
    bool handReleaseFB;
    int app_ID;

    double accX;
    double accY;
    double accZ;
    double accX_0;
    double accY_0;
    double accZ_0;
};