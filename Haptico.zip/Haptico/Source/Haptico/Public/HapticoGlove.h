#pragma once

#include "CoreMinimal.h"

#include "HapticoDevice.h"

#include "SerialPort.h"

//extern "C" {
//	#include "LeapC.h"
//}

#include <chai3d.h>

using namespace chai3d;

const char* port = "\\\\.\\COM5";

char output[255];
char incoming[255];

SerialPort arduino(port);

//extern const char* port;

class HapticoGlove : public HapticoDevice
{
public:
	HapticoGlove();

	~HapticoGlove();

public:
	cGenericHapticDevicePtr* leapDevice;

	virtual bool open();

	virtual bool close();

	virtual void disconnect();

	virtual bool calibrate(bool calibrated);

	virtual std::vector<FVector> getPositions();

	virtual std::vector<FMatrix> getRotations();

	virtual void setForces(std::vector<FVector> forces, std::vector<FVector> torques);

	int getNumberOfDevices();

	int getContactPoints();

	//LeapMotion Connection
	bool isConnected = false;
	unsigned int timeout_ms = 1000;

	//LEAP_CONNECTION connection;
	//LEAP_CONNECTION_MESSAGE msg;
	//LEAP_TRACKING_EVENT* latest_tracking_event;

	// a haptic device handler
	//cHapticDeviceHandler* handler;

	//// a pointer to the current haptic device
	//std::shared_ptr<cGenericHapticDevice> hapticDevice;

	//cGenericTool* tool;

	//cWorld* world;



private:


	unsigned int numberContactPoints = 3;

	static void updateHaptics(void);

	static void updateVibrations(void);

	void vibrate(const std::string& data);

	void vibrate(const int vibrationPattern[3]);
};
