#ifndef __CUSTOM_HAPTIC_DEVICE_HANDLER_H_
#define __CUSTOM_HAPTIC_DEVICE_HANDLER_H_

#include "devices/CGenericHapticDevice.h"
#include "HapticoDevice.h"

namespace CustomHapticHandler
{
	//==============================================================================
	/*!
	\file       CHapticDeviceHandler.h

	\brief
	Implements a universal haptic device handler.
	*/
	//==============================================================================

	//------------------------------------------------------------------------------
	//! Maximum number of devices that can be connected at the same time.
	const unsigned int C_MAX_HAPTIC_DEVICES = 16;
	//------------------------------------------------------------------------------

	//==============================================================================
	/*!
	\class      cHapticDeviceHandler
	\ingroup    devices

	\brief
	This class implements a universal haptic device handler.

	\details
	This class implements a manager which lists the different devices
	available on the computer and provides handles to them.
	*/
	//==============================================================================
	class CustomHapticDeviceHandler
	{
		//--------------------------------------------------------------------------
		// CONSTRUCTOR & DESTRUCTOR:
		//--------------------------------------------------------------------------

	public:

		//! Constructor of cHapticDeviceHandler.
		CustomHapticDeviceHandler();

		//! Destructor of cHapticDeviceHandler.
		virtual ~CustomHapticDeviceHandler();

		//--------------------------------------------------------------------------
		// PUBLIC METHODS:
		//--------------------------------------------------------------------------

	public:

		//! This method returns the number of devices currently connected to the computer.
		unsigned int getNumDevices() { return (m_numDevices); }

		//! This method updates information about the devices that are currently connected to the computer.
		void update(SupportedDevices type);

		//! This method returns the specifications of the i-th device.
		bool getDeviceSpecifications(chai3d::cHapticDeviceInfo& a_deviceSpecifications,
			unsigned int a_index = 0);

		//! This method returns a handle to the i-th device, if available.
		bool getDevice(chai3d::cGenericHapticDevicePtr&,
			unsigned int a_index = 0);

		bool getHapticoDevice(TSharedPtr<HapticoDevice>&, unsigned int a_index = 0);

		bool findDeviceOfType(SupportedDevices type);

		//--------------------------------------------------------------------------
		// PRIVATE MEMBERS:
		//--------------------------------------------------------------------------

	private:

		//! Number of devices.
		unsigned int m_numDevices;

		//! A default device with no functionalities.
		chai3d::cGenericHapticDevicePtr m_nullHapticDevice;

		//! Array of available haptic devices.
		chai3d::cGenericHapticDevicePtr m_devices[C_MAX_HAPTIC_DEVICES];

		TSharedPtr<HapticoDevice> nullDevice;

		TArray<TSharedPtr<HapticoDevice>> hapticDevices;
	};
}

#endif