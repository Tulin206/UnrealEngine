// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
class HapticoDevice;
typedef std::shared_ptr<HapticoDevice> cHapticoDevicePtr;
/**
 * 
 */
class HapticoDevice
{
public:
	HapticoDevice();

	HapticoDevice(unsigned int n);

	~HapticoDevice();

public:
	virtual bool open();

	virtual bool close();

	virtual void disconnect() {} ;

	virtual bool calibrate(bool calibrate) { return false; };

	virtual std::vector<FVector> getPositions();

	virtual std::vector<FMatrix> getRotations();

	virtual int getContactPoints() { return numberContactPoints;  };

	virtual void setForces(std::vector<FVector> forces, std::vector<FVector> torques) { return; };

	virtual int getNumberOfDevices();

public:
	unsigned int numberContactPoints  = 1;
};
