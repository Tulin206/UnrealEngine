// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "HapticStructsAndEnums.generated.h"

/// <summary>
/// Structure, used for storing translation data.
/// </summary>
USTRUCT()
struct FHapticData
{
	GENERATED_USTRUCT_BODY()

public:
	FVector location;
	FMatrix rotation;
	FVector linearVelocity;
	FVector angularVelocity;
	double DeltaTime = 0.0;
	double TotalTime = 0.0;
	uint64 loopCtr;

	std::vector<FVector> locations;
	std::vector<FMatrix> rotations;

	FString ToString()
	{
		FString TempString;

		TempString += location.ToString() + " ";
		TempString += rotation.ToString();
		TempString += linearVelocity.ToString();
		TempString += angularVelocity.ToString();
		TempString += FString::Printf(TEXT(" %f"), DeltaTime);
		TempString += FString::Printf(TEXT(" %f"), TotalTime);
		TempString += FString::Printf(TEXT(" %d "), loopCtr);

		return TempString;
	}
};

UENUM()
enum class SupportedDevices
{
	Falcon UMETA(DisplayName = "Falcon"),
	Glove UMETA(DisplayName = "Glove"),
	KinesCeti UMETA(DisplayName = "KinesCeti")
};

UENUM(BlueprintType)
enum class EHapticThreadType : uint8
{
	Delegate,
	SetHapticData,
	DelegateAndProvideData
};

/// <summary>
/// Simulation helper structure.
/// for Editor CSV import only. Defines the column names of the simulation data CSV file.
/// </summary>
USTRUCT(BlueprintType)
struct FSimDataCSV : public FTableRowBase // for use directly with data.table
{
	GENERATED_USTRUCT_BODY()

public:
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
	//	int32 HapticTime; // Time_ns

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		int32 HapticLoopCtr;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
	//	int32 Repetition;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		int32 SimulationStep; // SimIndex

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		FString Description;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		FString Type;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float locationX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float locationY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float locationZ;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M00;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M01;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M02;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M03;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M10;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M11;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M12;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M13;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M20;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M21;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M22;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M23;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M30;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M31;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M32;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float M33;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float linearVelocityX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float linearVelocityY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float linearVelocityZ;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float angularVelocityX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float angularVelocityY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float angularVelocityZ;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float deltaTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultForceX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultForceY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultForceZ;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultTorqueX;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultTorqueY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		float resultTorqueZ;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		int32 btn1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
		int32 btn2;

	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SimData)
	//	int32 Time_s;

	//double DeltaTime_ns;
	//double FPS;
};