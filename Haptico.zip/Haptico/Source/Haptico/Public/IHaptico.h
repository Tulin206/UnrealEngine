// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include <HapticStructsAndEnums.h>

DECLARE_LOG_CATEGORY_EXTERN(LogHaptico, All, All)

//UENUM()
//enum SupportedDevices
//{
//	Falcon UMETA(DisplayName = "Falcon"),
//	Glove UMETA(DisplayName = "Glove")
//};
/**
 * The public interface to the Haptico module.
 */
	class IHaptico : public IModuleInterface
{
public:

	/**
	 * Singleton-like access to this module's interface.  This is just for convenience!
	 * Beware of calling this during the shutdown phase, though.  Your module might have been unloaded already.
	 *
	 * @return Returns singleton instance, loading the module on demand if needed
	 */
	static inline IHaptico& Get()
	{
		return FModuleManager::LoadModuleChecked< IHaptico >("Haptico");
	}

	static inline void unloadM()
	{
		FModuleManager::Get().UnloadModule("Haptico");
	}

	/**
	* call this function to get the module when you are in another thread than the main thread
	*/

	/**
	 * Checks to see if this module is loaded and ready.  It is only valid to call Get() if IsAvailable() returns true.
	 *
	 * @return True if the module is loaded and ready to use
	 */
	static inline bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded("Haptico");
	}
	virtual FVector getForce() = 0;
	virtual FVector getTorque() = 0;
	virtual bool isFirstButtonActivated() = 0;
	virtual bool isSecondButtonActivated() = 0;
	virtual FVector getLinearVelocity() = 0;
	virtual FVector getAngularVelocity() = 0;
	virtual FVector getPosition() = 0;
	virtual FMatrix getRotation() = 0;
	virtual void measureTick(int32 numberOfTicks) = 0;
	virtual void setForce(FVector force) = 0;
	virtual void setTorque(FVector torque) = 0;
	virtual void ApplyForceAndTorque(FVector force, FVector torque) = 0;
	virtual bool connect() = 0;
	virtual bool findDeviceOfType(SupportedDevices type) = 0;
	virtual void disconnect() = 0;
	virtual void initMeasurementOfTicks() = 0;
	virtual void startTheClock() = 0;
	virtual void initDeltaTime() = 0;
	virtual double getDeltaTime() = 0;
	virtual void calibrate(bool forceCalibration) = 0;


	virtual int getNumberOfContactPoints() = 0;
	virtual std::vector<FVector> getPositions() = 0;
	virtual std::vector<FMatrix> getRotations() = 0;
	virtual void ApplyForces(std::vector<FVector> forces, std::vector<FVector> torques) = 0;
	virtual void SetDeviceType(SupportedDevices type) = 0;
};
