// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "IHaptico.h"
#include "Delegator.hxx"

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HapticStructsAndEnums.h"
#include "Engine/DataTable.h"

#include "HapticsManager.generated.h"

UCLASS(BlueprintType, hidecategories = (Input, Actor))
class HAPTICO_API AHapticsManager : public AActor
{
	GENERATED_BODY()

public:

	AHapticsManager();

	/*  The Delegate Event that is called right before sending new force values to the device */
	Delegator<> OnCalculateForce;

	/*  The Delegate Event that is called when receiving new device data */
	Delegator<const FHapticData&> OnAfterGatheringHapticData;

	/*  The Delegate Event in the first frame with a connected device */
	Delegator<const FHapticData&> OnAfterFirstHapticDataGathering;

	/* Delegate */
	DECLARE_DELEGATE(FOnAfterCalibratingDevice)
		FOnAfterCalibratingDevice OnAfterCalibratingDevice;

	/* Delegate */
	DECLARE_DELEGATE(FOnBeforeStartHapticLoop)
		FOnBeforeStartHapticLoop OnBeforeStartHapticLoop;

	/* Delegate called when clicking the first button of the haptics device (based on Chai3D framework), called in addition to BlueprintImplementableEvent event */
	DECLARE_DELEGATE(FOnButton1Clicked)
		FOnButton1Clicked OnButton1Clicked;

	/* Delegate called when clicking the second button of the haptics device (based on Chai3D framework), called in addition to BlueprintImplementableEvent event */
	DECLARE_DELEGATE(FOnButton2Clicked)
		FOnButton2Clicked OnButton2Clicked;

	/*  Decides which behavior the Haptic Thread shall use */
	UPROPERTY(EditAnywhere)
		EHapticThreadType HapticThreadType;

	/*  Decides wheter to measure Ticks or not to measure ticks (for debugging purposes) */
	UPROPERTY(EditAnywhere)
		bool bMeasureTheHapticTick;

	/*  Decides how many Ticks to measure Ticks */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bMeasureTheHapticTick"))
		int32 TicksToMeasure;

	/*  Loads the location and rotation data from file instead reading from the device */
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
		bool bSimulation;

	/*  Create a HapticThread_SimData DataTable by dragging the file to the content browser, select SimData as structure and paste it in here */
	UPROPERTY(EditAnywhere, meta = (EditCondition = "bSimulation"))
		UDataTable* SimulationDataTable;

	UPROPERTY()
		bool DeviceIsCalibrated = false;

protected:

	virtual void BeginPlay() override;
	virtual void EndPlay(EEndPlayReason::Type type) override;

public:

	virtual void Tick(float DeltaTime) override;

	void ExecuteForceCalculation();

	/*  Sets the force that will be applied each tick by the haptic loop */
	UFUNCTION(BlueprintCallable)
		static void StoreForce(FVector force);

	/*  Sets the torque that will be applied each tick by the haptic loop */
	UFUNCTION(BlueprintCallable, Category = "Haptics")
		static void StoreTorque(FVector torque);
		
	UFUNCTION(BlueprintCallable, Category = "Haptics")
		static void StoreID(int ID);

	//UFUNCTION(BlueprintCallable, Category = "Haptics")
		static void StoreForces(std::vector<FVector> forces, std::vector<FVector> torques);

	UFUNCTION(BlueprintCallable, Category = "Haptics")
		FVector getHapticDevicePosition();

	UFUNCTION(BlueprintCallable, Category = "Haptics")
		FMatrix getHapticDeviceRotation();

	UFUNCTION(BlueprintCallable, Category = "Haptics")
		FRotator getHapticDeviceRotationAsUnrealRotator();

	UFUNCTION(BlueprintCallable, Category = "Haptics")
		FVector getHapticDeviceAngularVelocity();

	UFUNCTION(BlueprintCallable, Category = "Haptics")
		FVector getHapticDeviceLinearVelocity();

	/* Blueprint event that can be overriden in a blueprint class of the HapticsManager class,
	   called when clicking the first button of the haptics device (based on Chai3D framework), called in addition to the delegate*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Button1Clicked"), Category = "Haptics")
		void button1Clicked();

	/* Blueprint event that can be overriden in a blueprint class of the HapticsManager class,
	   called when clicking the second button of the haptics device (based on Chai3D framework), called in addition to the delegate*/
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Button2Clicked"), Category = "Haptics")
		void button2Clicked();

	/// <summary>
	/// The offset of the device (difference from 0 after calibrating).
	/// Set at the beginning of the HapticLoop.
	/// </summary>
	UPROPERTY(VisibleAnywhere)
		FTransform CalibratedDeviceOffset;

	/// <summary>
	/// An offset of the device that gets added on top of the offset that is calculated from calibration
	/// Used to set CalibratedDeviceOffset at the beginning of the HapticLoop.
	/// </summary>
	UPROPERTY(EditAnywhere)
		FTransform AdditionalDeviceOffset;

	/* Scales the translation between haptic device (real life) space and Unreal level space */
	UPROPERTY(EditAnywhere)
		uint32 TranslationScale;

	/*  The Force that shall be applied until the next ticks calculation */
	FVector ForceOfNextTick;

	/*  The Force that shall be applied until the next ticks calculation (currently unsed because of our 3DOF-Device) */
	FVector TorqueOfNextTick;

	std::vector<FVector> ForcesOfNextTick = { FVector() };

	std::vector<FVector> TorquesOfNextTick = { FVector() };

	/*  Bifunctional converter between the Haptic and the Unreal space for Vectors
		@param pos  the Vector that shall be converted
		@return the converted FVector
	*/
	static FVector TranslateBetweenUnrealAndHapticVector(FVector pos);

	/*  Converter from the HapticSpace to the Unreal space for Rotators
		@param rotation  the RotationMatrix that shall be converted
		@return the FRotator of the Rotation
	*/
	FRotator TranslateToUnrealRotator(FMatrix rotation);

	FVector TranslateHapticLocationAndScaleToFVector(FVector pos, int32 scaling);

	FHapticData CurrentDeviceData;

	int componentID = 0;

	void StartHapticThread();

	int numberOfContactPoints;

	void ResizeBuffers();

protected:
};
