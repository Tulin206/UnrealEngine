// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "IHaptico.h"

/**
 *
 */
class HAPTICO_API HapticAlgorithms
{
public:
	HapticAlgorithms(IHaptico*);
	FVector pullToPoint(FVector position, FVector target, double maxForce = 1, double k = 100);
	bool isPlayerMoving();

private:
	IHaptico* haptico;
};
