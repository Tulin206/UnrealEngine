// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once
#include "CoreMinimal.h"
#include "HapticsManager.h"

/// <summary>
/// Storage class for store data, that will be transfered to the device
/// </summary>
class HAPTICO_API UHapticOutput
{
private:
	FVector hapticCursorPosition;
	FMatrix hapticCursorRotation;
	FVector hapticCursorLinearVelocity;
	FVector hapticCursorAngularVelocity;
	FHapticData HapticData;

public:
	static UHapticOutput& getInst();
	UHapticOutput();
	~UHapticOutput();

	FVector getHapticCursorLinearVelocity();
	FVector getHapticCursorAngularVelocity();
	void StoreHapticCursorLocation(FVector position);
	FVector getHapticCursorPosition();
	void StoreHapticCursorRotation(FMatrix rotation);
	FMatrix getHapticCursorRotation();
	void StoreHapticCursorAngularVelocity(FVector angularVelocity);
	void StoreHapticCursorLinearVelocity(FVector linearVelocity);
	void StoreHapticData(FHapticData data);
	FHapticData getHapticData();
};
