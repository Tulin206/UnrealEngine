// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once

#include "IHaptico.h"
#include "CoreMinimal.h"

/*
	This class is for Handling button presses on the haptic devices
*/
class HAPTICO_API HapticDeviceButtonHandler
{
public:
	HapticDeviceButtonHandler(IHaptico* haptico);
	bool button1Clicked();
	bool button2Clicked();

private:
	bool button1AlreadyPressed = false;
	bool button2AlreadyPressed = false;
	IHaptico* haptico;
};
