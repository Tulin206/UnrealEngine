// Copyright 2023 CGVR (zach@cs.uni-bremen.de). All Rights Reserved.

#pragma once
#include "CoreMinimal.h"

class HAPTICO_API UHapticInput
{
private:
	bool bStopThread = false;//set this to true to stop the thread
	FVector Force;
	FVector Torque;

	std::vector<FVector> Forces = { FVector(0,0,0) };
	std::vector<FVector> Torques = { FVector(0,0,0) };

	int ID;

public:
	static UHapticInput& getInst()
	{
		static UHapticInput instance;
		return instance;
	}
	bool ShouldThreadStop();
	void StopThread();
	void ResetStopThread();



	/*
		Sets the force that is applied to the device from now on
		in every tick of the haptic loop
		@param force  the force that shall be applied
	*/
	void StoreForce(FVector force);

	/*
	Sets the force that is applied to the device from now on
	in every tick of the haptic loop
	@param force  the force that shall be applied
	*/
	void StoreTorque(FVector torque);

	/*
		Gets the force that is applied to the device from now on
		in every tick of the haptic loop
		@return the force that shall be applied
	*/
	FVector GetStoredTorque();

	/*
	Gets the force that is applied to the device from now on
	in every tick of the haptic loop
	@return the force that shall be applied
	*/
	FVector GetStoredForce();

	void StoreForces(std::vector<FVector> InForces);

	void StoreTorques(std::vector<FVector> InTorques);

	std::vector<FVector> GetStoredForces();

	std::vector<FVector> GetStoredTorques();

	int GetStoredID();

	void StoreID(int id);
};