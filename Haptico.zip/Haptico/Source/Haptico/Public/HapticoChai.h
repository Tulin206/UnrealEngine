#pragma once

#include "CoreMinimal.h"

#include "HapticoDevice.h"

#include <chai3d.h>

using namespace chai3d;

class HapticoChai : public HapticoDevice
{
public:
	HapticoChai();

	~HapticoChai();

public:

	cGenericHapticDevicePtr* hapticDevice;

	virtual bool open();

	virtual bool close();

	virtual void disconnect();

	virtual bool calibrate(bool calibrated);

	virtual std::vector<FVector> getPositions();

	virtual bool getRotations(float* rotations) { return false; }

	virtual void setForces(std::vector<FVector> forces, std::vector<FVector> torques);

	int getNumberOfDevices();

private:
	unsigned int numberContactPoints = 1;
};
